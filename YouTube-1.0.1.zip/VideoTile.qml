import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Eine Kachel (Video, Kanal oder Playlist). Beim Überfahren mit der Maus bekommt das Vorschaubild
// einen Rahmen (Farbe, Stärke, Stil, Leuchten, Zoom aus den Einstellungen).
Item {
    id: tile
    property var item: ({})
    property var controller
    property var theme
    property real hue: 0                 // für den Regenbogen-Rahmen (von der Seite animiert)
    property bool preview: false         // Vorschau auf der Einstellungsseite
    signal activated()
    signal playNext()
    signal queue()
    signal later()
    signal openChannel(string channelId, string name)
    signal contextRequested(real x, real y)

    readonly property var c: controller
    function cfg(k) { return c ? c.get(k) : null }
    readonly property bool hovered: mouse.containsMouse || nextBtn.hovered || queueBtn.hovered || laterBtn.hovered
    readonly property bool isVideo: item.type === "video"
    readonly property bool isChannel: item.type === "channel"
    readonly property real radius: cfg("tileRadius")
    readonly property real bw: cfg("hoverWidth")
    readonly property color txt: theme ? theme.text : "#e6e8eb"
    readonly property color muted: theme ? theme.muted : "#8b93a1"
    readonly property color hoverColor: {
        var s = cfg("hoverStyle")
        if (s === "rainbow") return Qt.hsla(hue, 0.9, 0.58, 1)
        return cfg("hoverColor")
    }
    readonly property color hoverColor2: cfg("hoverStyle") === "gradient" ? Qt.hsla((hue + 0.33) % 1, 0.9, 0.6, 1) : hoverColor

    function thumbUrl() {
        if (item.thumb) return item.thumb
        if (!item.id) return ""
        var q = cfg("thumbQuality")
        var f = q === "mq" ? "mqdefault" : q === "max" ? "maxresdefault" : "hqdefault"
        return "https://i.ytimg.com/vi/" + item.id + "/" + f + ".jpg"
    }

    implicitHeight: thumbBox.height + info.implicitHeight + 10

    // ---- Vorschaubild ------------------------------------------------------------------------
    Item {
        id: thumbBox
        width: parent.width
        height: tile.isChannel ? width * 0.62 : width * 9 / 16
        scale: tile.hovered && tile.cfg("hoverZoom") ? 1.035 : 1
        y: tile.hovered && tile.cfg("hoverLift") ? -3 : 0
        z: 2
        Behavior on scale { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
        Behavior on y { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }

        // Leuchten: mehrere weiche Ringe hinter dem Bild
        Repeater {
            model: 4
            Rectangle {
                anchors.fill: parent
                anchors.margins: -(index + 1) * 3 - tile.bw
                radius: tile.radius + (index + 1) * 3 + tile.bw
                color: "transparent"
                border.width: 3
                border.color: Qt.rgba(tile.hoverColor.r, tile.hoverColor.g, tile.hoverColor.b, 0.22 - index * 0.05)
                opacity: tile.hovered && tile.cfg("hoverGlow") ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: 180 } }
            }
        }

        // Playlist: angedeuteter Stapel
        Repeater {
            model: tile.item.type === "playlist" ? 2 : 0
            Rectangle {
                x: (index + 1) * 6; y: -(index + 1) * 4
                width: parent.width - (index + 1) * 12; height: parent.height
                radius: tile.radius
                color: Qt.rgba(1, 1, 1, 0.08 + index * 0.04)
                z: -1
            }
        }

        Rectangle {
            id: frame
            anchors.fill: parent
            radius: tile.isChannel ? tile.radius * 1.4 : tile.radius
            color: theme ? theme.panel2 : "#1b1f26"
            clip: true

            // Platzhalter mit Schimmer, solange das Bild lädt
            Rectangle {
                anchors.fill: parent
                visible: img.status !== Image.Ready && !tile.isChannel
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: "transparent" }
                    GradientStop { position: shimmer.p; color: Qt.rgba(1, 1, 1, 0.07) }
                    GradientStop { position: 1; color: "transparent" }
                }
                QtObject { id: shimmer; property real p: 0.5 }
                SequentialAnimation on opacity { running: img.status === Image.Loading; loops: Animation.Infinite
                    NumberAnimation { from: 0.4; to: 1; duration: 700 } NumberAnimation { from: 1; to: 0.4; duration: 700 } }
            }

            Image {
                id: img
                visible: !tile.isChannel
                anchors.fill: parent
                source: tile.isChannel ? "" : tile.thumbUrl()
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                cache: true
                sourceSize.width: 480
                onStatusChanged: if (status === Image.Error && /maxresdefault/.test(String(source))) source = String(source).replace("maxresdefault", "hqdefault")
            }

            // Kanal: rundes Profilbild auf farbigem Grund
            Rectangle {
                visible: tile.isChannel
                anchors.fill: parent
                gradient: Gradient {
                    GradientStop { position: 0; color: Qt.hsla((tile.item.title ? tile.item.title.charCodeAt(0) % 36 : 0) / 36, 0.45, 0.28, 1) }
                    GradientStop { position: 1; color: theme ? theme.panel2 : "#1b1f26" }
                }
                Rectangle {
                    anchors.centerIn: parent
                    width: parent.height * 0.66; height: width; radius: width / 2
                    color: theme ? theme.panel : "#14171c"
                    clip: true
                    Image { anchors.fill: parent; source: tile.isChannel ? (tile.item.avatar || "") : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true }
                    Label { anchors.centerIn: parent; visible: !tile.item.avatar; text: (tile.item.title || "?").charAt(0); font.pixelSize: parent.width * 0.4; color: tile.txt }
                }
            }

            // Fortschritt (bereits angesehen)
            Rectangle {
                visible: tile.isVideo && tile.cfg("showProgress") && tile.item.progress > 0
                anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                height: 4
                color: Qt.rgba(1, 1, 1, 0.25)
                Rectangle { height: parent.height; width: parent.width * Math.min(100, tile.item.progress || 0) / 100; color: "#ff0033" }
            }

            // Abdunkeln + Play-Symbol beim Überfahren
            Rectangle {
                anchors.fill: parent
                color: "#000000"
                opacity: tile.hovered ? 0.28 : 0
                Behavior on opacity { NumberAnimation { duration: 160 } }
            }
            Rectangle {
                anchors.centerIn: parent
                width: 54; height: 54; radius: 27
                color: Qt.rgba(0, 0, 0, 0.55)
                border.color: Qt.rgba(1, 1, 1, 0.8); border.width: 2
                opacity: tile.hovered ? 1 : 0
                scale: tile.hovered ? 1 : 0.6
                Behavior on opacity { NumberAnimation { duration: 160 } }
                Behavior on scale { NumberAnimation { duration: 200; easing.type: Easing.OutBack } }
                Label {
                    anchors.centerIn: parent
                    anchors.horizontalCenterOffset: tile.isVideo ? 2 : 0
                    text: tile.isVideo ? "▶" : tile.isChannel ? "☰" : "≡"
                    font.pixelSize: 22; color: "white"
                }
            }

            // Abzeichen: Dauer / LIVE / Shorts / Anzahl
            Rectangle {
                anchors { right: parent.right; bottom: parent.bottom; margins: 7; bottomMargin: (tile.item.progress > 0 ? 10 : 7) }
                visible: badge.text !== ""
                radius: 4
                color: tile.item.live ? "#e00026" : Qt.rgba(0, 0, 0, 0.78)
                implicitWidth: badge.implicitWidth + 10; implicitHeight: badge.implicitHeight + 4
                Label {
                    id: badge
                    anchors.centerIn: parent
                    font.pixelSize: 11; font.bold: true; color: "white"
                    text: tile.item.live ? "● LIVE" : tile.item.short ? "SHORTS" : tile.item.type === "playlist" ? ("≡ " + (tile.item.count || "")) : (tile.item.duration || "")
                }
            }

            // Schnellaktionen
            Row {
                anchors { right: parent.right; top: parent.top; margins: 6 }
                spacing: 4
                visible: tile.isVideo && !tile.preview
                opacity: tile.hovered ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: 160 } }
                RoundButton {
                    id: laterBtn
                    readonly property bool on: { var g = tile.c ? tile.c.libraryGen : 0; return !!tile.c && tile.c.inLater(tile.item.id) }
                    width: 30; height: 30; padding: 0
                    text: on ? "✓" : "◷"; font.pixelSize: 14
                    onClicked: tile.later()
                    ToolTip.text: tile.c ? (on ? tile.c.t("Aus „Später ansehen“ entfernen", "Remove from “Watch later”") : tile.c.t("Später ansehen", "Watch later")) : ""
                    ToolTip.visible: hovered; ToolTip.delay: 400
                }
                RoundButton {
                    id: nextBtn
                    width: 30; height: 30; padding: 0
                    text: "⏭"; font.pixelSize: 13
                    onClicked: tile.playNext()
                    ToolTip.text: tile.c ? tile.c.t("Als Nächstes abspielen", "Play next") : ""; ToolTip.visible: hovered; ToolTip.delay: 400
                }
                RoundButton {
                    id: queueBtn
                    width: 30; height: 30; padding: 0
                    text: "+"; font.pixelSize: 16; font.bold: true
                    onClicked: tile.queue()
                    ToolTip.text: tile.c ? tile.c.t("Zur Playlist hinzufügen", "Add to playlist") : ""; ToolTip.visible: hovered; ToolTip.delay: 400
                }
            }
        }

        // Der Rahmen beim Überfahren
        Rectangle {
            id: hoverFrame
            anchors.fill: parent
            anchors.margins: -border.width / 2
            radius: frame.radius + border.width / 2
            color: "transparent"
            border.width: tile.hovered ? tile.bw : 0
            border.color: tile.hoverColor
            opacity: tile.hovered ? 1 : 0
            Behavior on border.width { NumberAnimation { duration: 140 } }
            Behavior on opacity { NumberAnimation { duration: 140 } }
            Behavior on border.color { enabled: tile.cfg("hoverStyle") === "solid"; ColorAnimation { duration: 140 } }
        }
        // zweite Farbe für den Verlaufs-Stil: innere Linie
        Rectangle {
            anchors.fill: parent
            anchors.margins: tile.bw / 2
            radius: Math.max(0, frame.radius - tile.bw / 2)
            color: "transparent"
            visible: tile.cfg("hoverStyle") === "gradient" && tile.hovered
            border.width: Math.max(1, tile.bw / 2)
            border.color: tile.hoverColor2
        }
    }

    // ---- Text --------------------------------------------------------------------------------
    RowLayout {
        id: info
        anchors { left: parent.left; right: parent.right; top: thumbBox.bottom; topMargin: 9 }
        spacing: 9
        Rectangle {
            visible: tile.isVideo && tile.cfg("showAvatars") && !!tile.item.avatar
            Layout.alignment: Qt.AlignTop
            implicitWidth: 34; implicitHeight: 34; radius: 17
            color: theme ? theme.panel2 : "#1b1f26"
            clip: true
            Image { anchors.fill: parent; source: parent.visible ? tile.item.avatar : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true; sourceSize.width: 68 }
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; enabled: !!tile.item.channelId
                        onClicked: tile.openChannel(tile.item.channelId, tile.item.channel) }
        }
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 3
            Label {
                Layout.fillWidth: true
                text: tile.item.title || ""
                color: tile.hovered ? Qt.lighter(tile.txt, 1.1) : tile.txt
                font.pixelSize: 14; font.weight: Font.DemiBold
                wrapMode: Text.Wrap; maximumLineCount: 2; elide: Text.ElideRight
                horizontalAlignment: tile.isChannel ? Text.AlignHCenter : Text.AlignLeft
            }
            Label {
                Layout.fillWidth: true
                visible: text !== ""
                text: tile.item.channel || ""
                color: chanMouse.containsMouse ? tile.txt : tile.muted
                font.pixelSize: 12; elide: Text.ElideRight
                font.underline: chanMouse.containsMouse && !!tile.item.channelId
                MouseArea { id: chanMouse; anchors.fill: parent; hoverEnabled: true; enabled: !!tile.item.channelId && !tile.isChannel
                            cursorShape: Qt.PointingHandCursor; onClicked: tile.openChannel(tile.item.channelId, tile.item.channel) }
            }
            Label {
                Layout.fillWidth: true
                visible: text !== ""
                text: tile.isVideo ? [tile.item.views, tile.item.age].filter(function (s) { return !!s }).join(" · ") : (tile.item.info || "")
                color: tile.muted; font.pixelSize: 12; elide: Text.ElideRight
                horizontalAlignment: tile.isChannel ? Text.AlignHCenter : Text.AlignLeft
            }
        }
    }

    MouseArea {
        id: mouse
        anchors.fill: thumbBox
        z: 1
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        cursorShape: Qt.PointingHandCursor
        onClicked: function (m) {
            if (m.button === Qt.RightButton) { var p = mapToItem(tile, m.x, m.y); tile.contextRequested(p.x, p.y) }
            else tile.activated()
        }
    }
}
