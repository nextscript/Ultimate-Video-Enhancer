import QtQml

// Datenquelle (YouTube Data API v3): ohne Anmeldung mit dem API-Key, mit verbundenem Google-Konto über OAuth.
// request(name, args, cb) -> cb(ok, dataOrError) mit { items, continuation, title }.
// Abos-Feed ohne API-Kontingent über die RSS-Feeds der Kanäle; Dauer/Live über videos.list (1 Einheit je 50 Videos).
QtObject {
    id: api
    property var controller
    readonly property bool ready: true
    property var _subs: null          // [{id, title, avatar}]
    property real _subsAt: 0
    property var _feed: null          // gemischter Abos-Feed (sortiert), Seiten werden daraus geschnitten
    readonly property int pageSize: 36

    // YouTubes Web-Schnittstelle (ohne Key/Kontingent): für die Suche und als Ersatz bei aufgebrauchtem Kontingent
    property var web: null
    Component.onCompleted: {
        var comp = Qt.createComponent(Qt.resolvedUrl("InnerTube.qml"))
        if (comp.status === Component.Ready) web = comp.createObject(api, { controller: controller })
        else console.warn("YouTube: InnerTube: " + comp.errorString())
    }
    // Kontingent aufgebraucht -> bis zum nächsten Zurücksetzen (08:00 UTC) keine weiteren API-Aufrufe ohne Anmeldung
    property real _quotaUntil: 0
    readonly property bool quotaOut: _quotaUntil > Date.now()
    function _markQuota() {
        var d = new Date(), r = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 8, 0, 0)
        if (r <= Date.now()) r += 86400000
        _quotaUntil = r
    }
    function _apiAvailable() { return controller.loggedIn || Date.now() >= _quotaUntil }

    function t(de, en) { return controller ? controller.t(de, en) : de }

    // ---- HTTP ----------------------------------------------------------------------------------
    function http(method, url, body, headers, cb) {
        var x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            var j = null
            try { j = x.responseText ? JSON.parse(x.responseText) : null } catch (e) { j = null }
            cb(x.status, j, x.responseText)
        }
        x.open(method, url)
        for (var k in (headers || {})) x.setRequestHeader(k, headers[k])
        x.send(body || null)
    }
    function form(o) { var a = []; for (var k in o) a.push(encodeURIComponent(k) + "=" + encodeURIComponent(o[k])); return a.join("&") }

    function withToken(cb) {
        var o = controller.get("oauth") || {}
        if (!o.refresh && !o.access) { cb(null, t("Nicht angemeldet", "Not signed in")); return }
        if (o.access && o.expiresAt - 60000 > Date.now()) { cb(o.access); return }
        controller.refreshToken(function (ok, tokOrErr) { if (ok) cb(tokOrErr); else cb(null, tokOrErr) })
    }
    // persönliche Abfragen (mine/myRating) brauchen OAuth; alles andere geht mit dem API-Key
    function get(path, params, cb, retried) {
        var personal = params.mine !== undefined || params.myRating !== undefined
        if (!controller.loggedIn && !personal) {
            var key = controller.apiKey
            var q = Object.assign({}, params); q.key = key
            http("GET", "https://www.googleapis.com/youtube/v3/" + path + "?" + form(q), null, {}, function (st, j) { handle(st, j, cb) })
            return
        }
        withToken(function (tok, err) {
            if (!tok) { cb(false, err); return }
            http("GET", "https://www.googleapis.com/youtube/v3/" + path + "?" + form(params), null, { "Authorization": "Bearer " + tok }, function (st, j) {
                if (st === 401 && !retried) { var o = Object.assign({}, controller.get("oauth")); o.expiresAt = 0; controller.set("oauth", o); get(path, params, cb, true); return }
                handle(st, j, cb)
            })
        })
    }
    function handle(st, j, cb) {
        if (st === 200) { cb(true, j); return }
        var reason = j && j.error && j.error.errors && j.error.errors[0] ? j.error.errors[0].reason : ""
        if ((reason === "quotaExceeded" || reason === "dailyLimitExceeded") && !controller.loggedIn) _markQuota()
        if (reason === "quotaExceeded" || reason === "dailyLimitExceeded")
            cb(false, t("Das tägliche YouTube-Kontingent ist aufgebraucht. Es setzt sich um 9 Uhr MEZ zurück.",
                        "The daily YouTube quota is used up. It resets at midnight Pacific time."))
        else if (reason === "keyInvalid" || (st === 400 && /API key/i.test(j && j.error ? j.error.message : "")))
            cb(false, t("Der eingebaute API-Key wurde von Google abgelehnt.", "Google rejected the built-in API key."))
        else if (reason === "accessNotConfigured" || reason === "SERVICE_DISABLED")
            cb(false, t("Für den eingebauten API-Key ist die „YouTube Data API v3“ nicht aktiviert.",
                        "The “YouTube Data API v3” is not enabled for the built-in API key."))
        else if (reason === "subscriptionForbidden")
            cb(false, t("Die Abos dieses Kanals sind privat. In YouTube → Einstellungen → Datenschutz „Alle meine Abos privat halten“ ausschalten und erneut importieren.",
                        "This channel's subscriptions are private. Turn off “Keep all my subscriptions private” in YouTube → Settings → Privacy and import again."))
        else cb(false, "HTTP " + st + (j && j.error ? ": " + j.error.message : ""))
    }

    // ---- Formatierung --------------------------------------------------------------------------
    function isoDur(s) {
        var m = /P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(s || "")
        if (!m) return ""
        var h = (parseInt(m[1] || 0) * 24) + parseInt(m[2] || 0), mi = parseInt(m[3] || 0), se = parseInt(m[4] || 0)
        if (!h && !mi && !se) return ""
        var pad = function (n) { return (n < 10 ? "0" : "") + n }
        return h ? h + ":" + pad(mi) + ":" + pad(se) : mi + ":" + pad(se)
    }
    function compact(n) {
        n = Number(n); if (!isFinite(n)) return ""
        var de = controller.lang === "de"
        function f(v) { var s = (v >= 10 ? Math.round(v) : Math.round(v * 10) / 10).toString(); return de ? s.replace(".", ",") : s }
        if (n >= 1e9) return f(n / 1e9) + (de ? " Mrd." : "B")
        if (n >= 1e6) return f(n / 1e6) + (de ? " Mio." : "M")
        if (n >= 1e3) return f(n / 1e3) + (de ? " Tsd." : "K")
        return String(n)
    }
    function views(n) { return n === undefined || n === null ? "" : compact(n) + t(" Aufrufe", " views") }
    function ago(iso) {
        var d = (Date.now() - Date.parse(iso)) / 1000
        if (!isFinite(d)) return ""
        var u = [[31536000, "Jahr", "Jahren", "year"], [2592000, "Monat", "Monaten", "month"], [604800, "Woche", "Wochen", "week"],
                 [86400, "Tag", "Tagen", "day"], [3600, "Stunde", "Stunden", "hour"], [60, "Minute", "Minuten", "minute"]]
        for (var i = 0; i < u.length; i++) {
            var n = Math.floor(d / u[i][0])
            if (n >= 1) return controller.lang === "de" ? "vor " + n + " " + (n === 1 ? u[i][1] : u[i][2]) : n + " " + u[i][3] + (n === 1 ? "" : "s") + " ago"
        }
        return t("gerade eben", "just now")
    }
    function thumbOf(sn) { var th = sn && sn.thumbnails; if (!th) return ""; var b = th.high || th.medium || th.default; return b ? b.url : "" }
    function decode(s) { return String(s || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&#39;/g, "'") }

    function videoFrom(v) {
        var sn = v.snippet || {}, cd = v.contentDetails || {}, st = v.statistics || {}
        var dur = isoDur(cd.duration)
        var live = sn.liveBroadcastContent === "live"
        return { type: "video", id: v.id, title: sn.title || "", channel: sn.channelTitle || "", channelId: sn.channelId || "",
                 duration: live ? "" : dur, views: views(st.viewCount), age: sn.publishedAt ? ago(sn.publishedAt) : "",
                 live: live, short: false, progress: 0, avatar: "", _pub: Date.parse(sn.publishedAt || 0) }
    }
    // Details (Dauer, Aufrufe, Live) und Kanalbilder zu einer Liste von Video-IDs
    function details(ids, cb) {
        if (!_apiAvailable()) { cb(false, "quota"); return }
        var out = {}, chunks = []
        for (var i = 0; i < ids.length; i += 50) chunks.push(ids.slice(i, i + 50))
        if (!chunks.length) { cb(true, out); return }
        var left = chunks.length, failed = null
        chunks.forEach(function (c) {
            get("videos", { part: "snippet,contentDetails,statistics", id: c.join(","), maxResults: 50, hl: controller.hl() }, function (ok, j) {
                if (ok) (j.items || []).forEach(function (v) { out[v.id] = videoFrom(v) }); else failed = j
                if (--left === 0) cb(!failed || Object.keys(out).length > 0, failed && !Object.keys(out).length ? failed : out)
            })
        })
    }
    function avatars(items, cb) {
        if (!controller.get("showAvatars") || !_apiAvailable()) { cb(items); return }
        var known = {}, need = []
        ;(_subs || controller.get("localSubs") || []).forEach(function (s) { known[s.id] = s.avatar })
        items.forEach(function (i) { if (i.channelId && !known[i.channelId] && need.indexOf(i.channelId) < 0) need.push(i.channelId) })
        var apply = function () { items.forEach(function (i) { if (i.channelId && known[i.channelId]) i.avatar = known[i.channelId] }); cb(items) }
        if (!need.length) { apply(); return }
        get("channels", { part: "snippet", id: need.slice(0, 50).join(","), maxResults: 50 }, function (ok, j) {
            if (ok) (j.items || []).forEach(function (c) { known[c.id] = thumbOf(c.snippet) })
            apply()
        })
    }
    function finishVideos(list, cont, title, cb) {
        avatars(list, function (l) { cb(true, { items: l, continuation: cont || "", title: title || "" }) })
    }

    // ---- Abos ----------------------------------------------------------------------------------
    function subscriptions(cb) {
        if (!controller.loggedIn) { cb(true, (controller.get("localSubs") || []).slice()); return }
        if (_subs && Date.now() - _subsAt < 600000) { cb(true, _subs); return }
        var all = []
        var page = function (token) {
            var p = { part: "snippet", mine: "true", maxResults: 50, order: "relevance" }
            if (token) p.pageToken = token
            get("subscriptions", p, function (ok, j) {
                if (!ok) { cb(false, j); return }
                ;(j.items || []).forEach(function (s) {
                    var sn = s.snippet || {}
                    all.push({ id: sn.resourceId ? sn.resourceId.channelId : "", title: sn.title || "", avatar: thumbOf(sn) })
                })
                if (j.nextPageToken && all.length < 1000) page(j.nextPageToken)
                else { _subs = all; _subsAt = Date.now(); cb(true, all) }
            })
        }
        page("")
    }
    function rss(channelId, cb) {
        http("GET", "https://www.youtube.com/feeds/videos.xml?channel_id=" + channelId, null, {}, function (st, j, text) {
            if (st !== 200 || !text) { cb([]); return }
            var out = [], re = /<entry>([\s\S]*?)<\/entry>/g, m
            while ((m = re.exec(text))) {
                var e = m[1]
                var g = function (r) { var x = r.exec(e); return x ? decode(x[1]) : "" }
                var id = g(/<yt:videoId>([^<]+)</)
                if (!id) continue
                var link = g(/<link rel="alternate" href="([^"]+)"/)
                out.push({ id: id, title: g(/<title>([^<]*)</), channel: g(/<name>([^<]*)</), channelId: channelId,
                           pub: Date.parse(g(/<published>([^<]+)</)), short: /\/shorts\//.test(link) })
            }
            cb(out)
        })
    }
    function subsFeed(start, cb) {
        if (start > 0 && _feed) { feedPage(start, cb); return }
        subscriptions(function (ok, subs) {
            if (!ok) { cb(false, subs); return }
            var chans = subs.slice(0, controller.get("subsFeedChannels"))
            if (!chans.length) {
                cb(false, t("Noch keine Abos. Öffne einen Kanal und klicke auf „Abonnieren“ – oder importiere deine YouTube-Abos unter Einstellungen → YouTube.",
                            "No subscriptions yet. Open a channel and click “Subscribe” – or import your YouTube subscriptions under Settings → YouTube."))
                return
            }
            var merged = [], left = chans.length
            chans.forEach(function (c) {
                rss(c.id, function (list) {
                    list.forEach(function (v) { v.avatar = c.avatar; merged.push(v) })
                    if (--left === 0) {
                        merged.sort(function (a, b) { return b.pub - a.pub })
                        _feed = merged.slice(0, 300)
                        feedPage(0, cb)
                    }
                })
            })
        })
    }
    function feedPage(start, cb) {
        var slice = _feed.slice(start, start + pageSize)
        details(slice.map(function (v) { return v.id }), function (ok, map) {
            var items = slice.map(function (v) {
                var d = ok && map[v.id]
                var it = d ? d : { type: "video", id: v.id, title: v.title, channel: v.channel, channelId: v.channelId, duration: "", views: "", age: "", live: false, progress: 0 }
                it.age = ago(new Date(v.pub).toISOString()); it.avatar = v.avatar; it.short = v.short
                return it
            })
            cb(true, { items: items, continuation: start + pageSize < _feed.length ? "feed:" + (start + pageSize) : "", title: "" })
        })
    }

    // ---- Listen aus Playlists ------------------------------------------------------------------
    function playlistVideos(playlistId, token, title, cb) {
        var p = { part: "snippet,contentDetails", playlistId: playlistId, maxResults: 50 }
        if (token) p.pageToken = token
        get("playlistItems", p, function (ok, j) {
            if (!ok) {
                // Kanal-Uploads gehen auch ohne Kontingent über den RSS-Feed des Kanals (die neuesten 15)
                if (!token && playlistId.indexOf("UU") === 0)
                    return webBrowse("UC" + playlistId.substring(2), "EgZ2aWRlb3PyBgQKAjoA", "", title, function (ok2, d2) {
                        if (ok2 && d2.items.length) cb(true, d2); else rssChannel("UC" + playlistId.substring(2), title, cb, j)
                    })
                if (!token) return webBrowse("VL" + playlistId, "", "", title, function (ok2, d2) { if (ok2 && d2.items.length) cb(true, d2); else cb(false, j) })
                cb(false, j); return
            }
            var rows = (j.items || []).filter(function (i) { return i.snippet && i.snippet.title !== "Private video" && i.snippet.title !== "Deleted video" })
            var ids = rows.map(function (i) { return i.contentDetails.videoId })
            details(ids, function (ok2, map) {
                var list = rows.map(function (r) {
                    var id = r.contentDetails.videoId, sn = r.snippet
                    return (ok2 && map[id]) || { type: "video", id: id, title: sn.title || "", channel: sn.videoOwnerChannelTitle || sn.channelTitle || "",
                                                 channelId: sn.videoOwnerChannelId || sn.channelId || "", duration: "", views: "",
                                                 age: r.contentDetails.videoPublishedAt ? ago(r.contentDetails.videoPublishedAt) : "", live: false, short: false, progress: 0, avatar: "" }
                })
                finishVideos(list, j.nextPageToken ? "pl:" + j.nextPageToken : "", title, cb)
            })
        })
    }
    function rssChannel(channelId, title, cb, prevError) {
        rss(channelId, function (list) {
            if (!list.length) { cb(false, prevError || "RSS"); return }
            var known = {}; (controller.get("localSubs") || []).forEach(function (s) { known[s.id] = s.avatar })
            details(list.map(function (v) { return v.id }), function (ok, map) {
                var items = list.map(function (v) {
                    var it = (ok && map[v.id]) || { type: "video", id: v.id, title: v.title, channel: v.channel, channelId: channelId, duration: "", views: "", live: false, progress: 0 }
                    it.age = ago(new Date(v.pub).toISOString()); it.short = v.short; it.avatar = it.avatar || known[channelId] || ""
                    return it
                })
                cb(true, { items: items, continuation: "", title: title || (list[0] ? list[0].channel : "") })
            })
        })
    }
    function chartOrRated(params, token, cb) {
        var p = Object.assign({ part: "snippet,contentDetails,statistics", maxResults: 48, hl: controller.hl() }, params)
        if (token) p.pageToken = token
        get("videos", p, function (ok, j) {
            if (!ok) { cb(false, j); return }
            finishVideos((j.items || []).map(videoFrom), j.nextPageToken ? "pt:" + j.nextPageToken : "", "", cb)
        })
    }

    // ---- Befehle (wie YtBridge) ----------------------------------------------------------------
    function request(name, args, cb) {
        args = args || {}
        try {
            if (name === "status") return status(cb)
            if (name === "search") return search(args, cb)
            if (name === "browse") return browse(args, cb)
            cb(false, "unknown op")
        } catch (e) { cb(false, String(e)) }
    }
    function status(cb) {
        var o = controller.get("oauth") || {}
        if (!o.refresh) { cb(true, { loggedIn: false, account: null }); return }
        get("channels", { part: "snippet", mine: "true" }, function (ok, j) {
            if (!ok) { cb(true, { loggedIn: !!o.refresh, account: controller.account }); return }
            var c = j.items && j.items[0], sn = c ? c.snippet : null
            cb(true, { loggedIn: true, account: sn ? { name: sn.title, handle: sn.customUrl || "", photo: thumbOf(sn) } : null })
        })
    }
    function region() { var g = controller.gl(); if (g) return g; var l = controller.lang; return l === "en" ? "US" : l === "el" ? "GR" : l.toUpperCase() }
    function tokenOf(cont, prefix) { return cont && cont.indexOf(prefix) === 0 ? cont.substring(prefix.length) : "" }

    function browse(a, cb) {
        var id = a.browseId || "", cont = a.continuation || ""
        if (cont.indexOf("feed:") === 0) return feedPage(parseInt(cont.substring(5)), cb)
        if (cont.indexOf("it:") === 0) return webBrowse("", "", cont.substring(3), "", cb)
        if (cont.indexOf("subs:") === 0) return channelsPage(parseInt(cont.substring(5)), cb)
        if (cont) {   // Fortsetzung: Ziel steckt in _lastBrowse
            var lb = _lastBrowse
            if (!lb) { cb(false, "no context"); return }
            if (cont.indexOf("pl:") === 0) return playlistVideos(lb.playlistId, tokenOf(cont, "pl:"), lb.title, cb)
            if (cont.indexOf("pt:") === 0) return chartOrRated(lb.params, tokenOf(cont, "pt:"), cb)
            if (cont.indexOf("pls:") === 0) return myPlaylists(tokenOf(cont, "pls:"), cb)
            if (cont.indexOf("cpl:") === 0) return channelPlaylists(lb.channelId, tokenOf(cont, "cpl:"), cb)
            cb(false, "bad continuation"); return
        }
        if (id === "FEwhat_to_watch") {
            _lastBrowse = { params: { chart: "mostPopular", regionCode: region() } }
            if (!_apiAvailable()) return forYou(cb)
            return chartOrRated(_lastBrowse.params, "", function (ok, d) { if (ok) cb(ok, d); else forYou(cb, d) })
        }
        if (id === "FEsubscriptions") return subsFeed(0, cb)
        if (id === "FEchannels") return channelsPage(0, cb)
        if (id === "FEhistory") return localList("history", t("Noch nichts abgespielt.", "Nothing played yet."), cb)
        if (id === "VLWL") return localList("watchLater", t("Noch nichts gemerkt. Rechtsklick auf ein Video → „Später ansehen“.", "Nothing saved yet. Right-click a video → “Watch later”."), cb)
        if (id === "VLLL") {
            if (!controller.loggedIn) return localList("favorites", t("Noch keine Favoriten. Rechtsklick auf ein Video → „Zu Favoriten“.", "No favourites yet. Right-click a video → “Add to favourites”."), cb)
            _lastBrowse = { params: { myRating: "like" } }; return chartOrRated(_lastBrowse.params, "", cb)
        }
        if (id === "FEplaylist_aggregation") {
            if (controller.loggedIn) return myPlaylists("", cb)
            var cid = controller.get("myChannelId")
            if (!cid) { cb(false, t("Trage unter Einstellungen → YouTube deinen Kanal (@name) ein, um deine öffentlichen Playlists zu sehen.", "Enter your channel (@name) under Settings → YouTube to see your public playlists.")); return }
            return channelPlaylists(cid, "", cb)
        }
        if (id.indexOf("UC") === 0) {
            _lastBrowse = { playlistId: "UU" + id.substring(2), title: "" }
            if (!_apiAvailable()) return webBrowse(id, "EgZ2aWRlb3PyBgQKAjoA", "", "", cb)
            get("channels", { part: "snippet", id: id }, function (ok, j) {
                var title = ok && j.items && j.items[0] ? j.items[0].snippet.title : ""
                _lastBrowse.title = title
                playlistVideos(_lastBrowse.playlistId, "", title, cb)
            })
            return
        }
        if (id.indexOf("VL") === 0) {
            var pl = id.substring(2)
            _lastBrowse = { playlistId: pl, title: "" }
            if (!_apiAvailable()) return webBrowse(id, "", "", "", cb)
            get("playlists", { part: "snippet", id: pl }, function (ok, j) {
                var title = ok && j.items && j.items[0] ? j.items[0].snippet.title : ""
                _lastBrowse.title = title
                playlistVideos(pl, "", title, cb)
            })
            return
        }
        cb(false, "unsupported: " + id)
    }
    property var _lastBrowse: null

    function channelsPage(start, cb) {
        subscriptions(function (ok, subs) {
            if (!ok) { cb(false, subs); return }
            var sorted = subs.slice().sort(function (a, b) { return a.title.localeCompare(b.title) })
            var slice = sorted.slice(start, start + 60).map(function (s) { return { type: "channel", id: s.id, title: s.title, avatar: s.avatar, info: "" } })
            cb(true, { items: slice, continuation: start + 60 < sorted.length ? "subs:" + (start + 60) : "", title: "" })
        })
    }
    function localList(key, emptyMsg, cb) {
        var l = (controller.get(key) || []).map(function (x) { return Object.assign({}, x) })
        if (!l.length) { cb(false, emptyMsg); return }
        cb(true, { items: l, continuation: "", title: "" })
    }
    function playlistItemFrom(pl) {
        return { type: "playlist", id: pl.id, title: pl.snippet.title, channel: pl.snippet.channelTitle, thumb: thumbOf(pl.snippet),
                 count: (pl.contentDetails ? pl.contentDetails.itemCount : "") + t(" Videos", " videos"), info: "" }
    }
    function channelPlaylists(channelId, token, cb) {
        _lastBrowse = { channelId: channelId }
        var p = { part: "snippet,contentDetails", channelId: channelId, maxResults: 50 }
        if (token) p.pageToken = token
        get("playlists", p, function (ok, j) {
            if (!ok) { cb(false, j); return }
            cb(true, { items: (j.items || []).map(playlistItemFrom), continuation: j.nextPageToken ? "cpl:" + j.nextPageToken : "", title: "" })
        })
    }
    // @name oder Kanal-URL -> { id, title, avatar }
    function resolveHandle(input, cb) {
        var h = String(input || "").trim()
        var m = /channel\/(UC[\w-]{22})/.exec(h)
        var p
        if (m || /^UC[\w-]{22}$/.test(h)) p = { part: "snippet", id: m ? m[1] : h }
        else {
            var hm = /@([\w.\-]+)/.exec(h)
            p = { part: "snippet", forHandle: "@" + (hm ? hm[1] : h.replace(/^@/, "")) }
        }
        get("channels", p, function (ok, j) {
            if (!ok) { cb(false, j); return }
            var c = j.items && j.items[0]
            if (!c) { cb(false, t("Kanal nicht gefunden: ", "Channel not found: ") + h); return }
            cb(true, { id: c.id, title: c.snippet.title, avatar: thumbOf(c.snippet) })
        })
    }
    function publicSubscriptions(channelId, cb) {
        var all = []
        var page = function (token) {
            var p = { part: "snippet", channelId: channelId, maxResults: 50, order: "relevance" }
            if (token) p.pageToken = token
            get("subscriptions", p, function (ok, j) {
                if (!ok) { cb(false, j); return }
                ;(j.items || []).forEach(function (s) {
                    var sn = s.snippet || {}
                    all.push({ id: sn.resourceId ? sn.resourceId.channelId : "", title: sn.title || "", avatar: thumbOf(sn) })
                })
                if (j.nextPageToken && all.length < 2000) page(j.nextPageToken); else cb(true, all)
            })
        }
        page("")
    }
    function myPlaylists(token, cb) {
        _lastBrowse = {}
        var p = { part: "snippet,contentDetails", mine: "true", maxResults: 50 }
        if (token) p.pageToken = token
        get("playlists", p, function (ok, j) {
            if (!ok) { cb(false, j); return }
            var items = (j.items || []).map(function (pl) {
                return { type: "playlist", id: pl.id, title: pl.snippet.title, channel: pl.snippet.channelTitle, thumb: thumbOf(pl.snippet),
                         count: (pl.contentDetails ? pl.contentDetails.itemCount : "") + t(" Videos", " videos"), info: "" }
            })
            if (!token) items.unshift({ type: "playlist", id: "LL", title: t("Mag ich", "Liked videos"), channel: "", thumb: "", count: "♥", info: "" })
            cb(true, { items: items, continuation: j.nextPageToken ? "pls:" + j.nextPageToken : "", title: "" })
        })
    }

    function search(a, cb) {
        if (web) {
            web.search(a.query, a.params || "", a.continuation || "", function (ok, d) {
                if (ok) { cb(true, { items: d.items, continuation: d.continuation, title: "" }); return }
                if (a.continuation) { cb(false, d); return }
                apiSearch(a, cb)
            })
            return
        }
        apiSearch(a, cb)
    }
    function apiSearch(a, cb) {
        var types = { "": "video,channel,playlist", "EgIQAQ==": "video", "EgJAAQ==": "video", "EgIQAg==": "channel", "EgIQAw==": "playlist" }
        var p
        if (a.continuation) { p = Object.assign({}, _lastSearch); p.pageToken = a.continuation }
        else {
            p = { part: "snippet", q: a.query, maxResults: 25, type: types[a.params || ""] || "video,channel,playlist", relevanceLanguage: controller.hl(), regionCode: region() }
            if (a.params === "EgJAAQ==") p.eventType = "live"
            _lastSearch = p
        }
        get("search", p, function (ok, j) {
            if (!ok) { cb(false, j); return }
            var raw = j.items || [], vids = []
            raw.forEach(function (r) { if (r.id.kind === "youtube#video") vids.push(r.id.videoId) })
            details(vids, function (ok2, map) {
                var items = raw.map(function (r) {
                    var sn = r.snippet || {}
                    if (r.id.kind === "youtube#video") return map[r.id.videoId] || { type: "video", id: r.id.videoId, title: decode(sn.title), channel: sn.channelTitle, channelId: sn.channelId, live: sn.liveBroadcastContent === "live", age: ago(sn.publishedAt), views: "", duration: "", progress: 0 }
                    if (r.id.kind === "youtube#channel") return { type: "channel", id: r.id.channelId, title: decode(sn.title), avatar: thumbOf(sn), info: "" }
                    if (r.id.kind === "youtube#playlist") return { type: "playlist", id: r.id.playlistId, title: decode(sn.title), channel: sn.channelTitle, thumb: thumbOf(sn), count: "", info: "" }
                    return null
                }).filter(function (x) { return !!x })
                finishVideos(items, j.nextPageToken || "", "", cb)
            })
        })
    }
    property var _lastSearch: ({})

    // ---- Web-Schnittstelle ---------------------------------------------------------------------
    function webBrowse(browseId, params, continuation, title, cb) {
        if (!web) { cb(false, "InnerTube"); return }
        web.browse(browseId, params, continuation, function (ok, d) {
            if (!ok) { cb(false, d); return }
            var known = {}
            ;(controller.get("localSubs") || []).forEach(function (s) { known[s.id] = s.avatar })
            if (browseId) _webCtx = browseId.indexOf("UC") === 0 ? { channel: d.title || title || "", channelId: browseId, avatar: d.avatar || "" } : null
            var ctx = _webCtx
            d.items.forEach(function (i) {
                if (i.type !== "video") return
                if (ctx && !i.channel) { i.channel = ctx.channel; i.channelId = ctx.channelId; if (!i.avatar) i.avatar = ctx.avatar }
                if (!i.avatar && known[i.channelId]) i.avatar = known[i.channelId]
            })
            cb(true, { items: d.items, continuation: d.continuation ? "it:" + d.continuation : "", title: d.title || title || "" })
        })
    }
    property var _webCtx: null
    // "Für dich": ähnliche Videos zu den zuletzt gesehenen und zu den neuesten Videos deiner Abos
    function forYou(cb, prevError) {
        if (!web) { cb(false, prevError || "InnerTube"); return }
        var seeds = (controller.get("history") || []).slice(0, 4).map(function (v) { return v.id })
        var fav = (controller.get("favorites") || []).slice(0, 2).map(function (v) { return v.id })
        seeds = seeds.concat(fav.filter(function (x) { return seeds.indexOf(x) < 0 }))
        var collect = function (seedIds) {
            if (!seedIds.length) {
                cb(false, t("Trends sind gerade nicht verfügbar. Schau ein paar Videos oder abonniere Kanäle – dann stellt „Trends“ hier passende Empfehlungen für dich zusammen.",
                            "Trending is not available right now. Watch a few videos or subscribe to channels – “Trending” then shows recommendations for you here."))
                return
            }
            var all = [], seen = {}, left = seedIds.length
            seedIds.forEach(function (sid) { seen[sid] = 1 })
            seedIds.forEach(function (sid, n) {
                web.related(sid, function (ok, list) {
                    if (ok) list.slice(0, 14).forEach(function (v, i) { if (!seen[v.type + v.id]) { seen[v.type + v.id] = 1; v._rank = i * 10 + n; all.push(v) } })
                    if (--left === 0) {
                        all.sort(function (a, b) { return a._rank - b._rank })
                        cb(true, { items: all, continuation: "", title: t("Für dich", "For you") })
                    }
                })
            })
        }
        if (seeds.length) { collect(seeds); return }
        // ohne Verlauf: neueste Videos der Abos als Ausgangspunkt
        var subs = (controller.get("localSubs") || []).slice(0, 4)
        if (!subs.length) { collect([]); return }
        var picks = [], left = subs.length
        subs.forEach(function (c) {
            rss(c.id, function (list) {
                if (list.length) picks.push(list[0].id)
                if (--left === 0) collect(picks)
            })
        })
    }
}
