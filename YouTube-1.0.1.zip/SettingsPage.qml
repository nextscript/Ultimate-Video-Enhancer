import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Eigene Seite unter Einstellungen → YouTube: Zugang & Abos, Bibliothek, Kacheln & Hover-Rahmen, Inhalte, Wiedergabe, Fenster, Region, Google-Konto (optional).
ColumnLayout {
    id: page
    property var theme
    property var plugin
    property var controller

    readonly property var c: controller
    function tr(de, en) { return c ? c.t(de, en) : de }
    function cfg(k) { return c ? c.get(k) : null }
    function put(k, v) { if (c) c.set(k, v) }

    readonly property color cText: theme ? theme.text : "#e6e8eb"
    readonly property color cMuted: theme ? theme.muted : "#8b93a1"
    readonly property color cPanel: theme ? theme.panel : "#14171c"
    readonly property color cPanel2: theme ? theme.panel2 : "#1b1f26"
    readonly property color cLine: theme ? theme.line : "#262b34"
    readonly property color ytRed: "#ff0033"
    property real hue: 0
    property bool showLogin: false
    property string loginMode: "login"
    NumberAnimation on hue { from: 0; to: 1; duration: 4000; loops: Animation.Infinite; running: page.cfg("hoverStyle") !== "solid" }

    spacing: 14

    property bool checking: false
    function refreshStatus() {
        if (!(c && c.api && c.loggedIn)) return
        checking = true
        c.api.request("status", {}, function (ok, d) { page.checking = false; if (ok) page.c.setStatus(!!d.loggedIn, d.account) })
    }
    onControllerChanged: Qt.callLater(refreshStatus)

    function openLogin(mode) {
        if (mode === "logout") { c.logoutOAuth(); return }
        loginMode = mode; showLogin = true
        loginLoader.setSource(Qt.resolvedUrl("BrowserLoginView.qml"), { controller: c, theme: theme })
    }
    onShowLoginChanged: if (!showLogin) loginLoader.source = ""

    property string importState: ""
    property bool importing: false

    component SectionTitle: RowLayout {
        property var pg
        property alias text: st.text
        Layout.topMargin: 10
        spacing: 10
        Rectangle { implicitWidth: 4; implicitHeight: 18; radius: 2; color: "#ff0033" }
        Label { id: st; color: pg ? pg.cText : "white"; font.pixelSize: 15; font.bold: true }
    }
    component Card: Rectangle {
        property var pg
        default property alias content: inner.data
        Layout.fillWidth: true
        implicitHeight: inner.implicitHeight + 28
        radius: 12
        color: pg.cPanel2
        border.color: pg.cLine
        ColumnLayout { id: inner; anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 } spacing: 10 }
    }
    component Row2: RowLayout {
        property var pg
        property alias label: l.text
        property alias hint: h.text
        Layout.fillWidth: true
        spacing: 12
        ColumnLayout {
            Layout.fillWidth: true; spacing: 1
            Label { id: l; Layout.fillWidth: true; color: pg.cText; wrapMode: Text.Wrap }
            Label { id: h; Layout.fillWidth: true; visible: text !== ""; color: pg.cMuted; font.pixelSize: 12; wrapMode: Text.Wrap }
        }
    }
    component Toggle: Row2 {
        id: tg
        property string key
        Switch { checked: pg.cfg(tg.key) === true; onToggled: pg.put(tg.key, checked) }
    }
    component Choice: Row2 {
        id: ch
        property string key
        property var options: []    // [{v, de, en}]
        ComboBox {
            Layout.preferredWidth: 230
            model: ch.options.map(function (o) { return pg.tr(o.de, o.en) })
            currentIndex: Math.max(0, ch.options.findIndex(function (o) { return o.v === pg.cfg(ch.key) }))
            onActivated: function (i) { pg.put(ch.key, ch.options[i].v) }
        }
    }
    component Slide: Row2 {
        id: sl
        property string key
        property real from: 0
        property real to: 10
        property real step: 1
        property string unit: ""
        Slider {
            Layout.preferredWidth: 190
            from: sl.from; to: sl.to; stepSize: sl.step; snapMode: Slider.SnapAlways
            value: pg.cfg(sl.key)
            onMoved: pg.put(sl.key, value)
        }
        Label { Layout.preferredWidth: 48; text: Math.round(pg.cfg(sl.key)) + sl.unit; color: pg.cMuted; horizontalAlignment: Text.AlignRight }
    }

    // ---- Kopf ---------------------------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: heroCol.implicitHeight + 36
        radius: 16
        clip: true
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: "#3a0010" }
            GradientStop { position: 0.55; color: "#1c0a14" }
            GradientStop { position: 1; color: page.cPanel2 }
        }
        border.color: Qt.rgba(1, 0, 0.2, 0.35)
        Repeater {
            model: 5
            Label {
                text: "▶"; color: Qt.rgba(1, 1, 1, 0.035 + index * 0.008)
                font.pixelSize: 40 + index * 26
                x: parent.width - 80 - index * 70; y: -10 + (index % 2) * 30
                rotation: -12 + index * 6
            }
        }
        ColumnLayout {
            id: heroCol
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 18 }
            spacing: 12
            RowLayout {
                spacing: 14
                Rectangle {
                    implicitWidth: 64; implicitHeight: 64; radius: 32
                    color: "#2a2e36"
                    border.width: 3
                    border.color: page.ytRed
                    clip: true
                    Image { anchors.fill: parent; anchors.margins: 3; source: page.c && page.c.loggedIn && page.c.account && page.c.account.photo ? page.c.account.photo : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true }
                    Label { anchors.centerIn: parent; visible: !(page.c && page.c.loggedIn && page.c.account && page.c.account.photo); text: "▶"; color: page.ytRed; font.pixelSize: 24 }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    Label {
                        Layout.fillWidth: true; elide: Text.ElideRight
                        color: "white"; font.pixelSize: 20; font.weight: Font.Bold
                        text: page.c && page.c.loggedIn && page.c.account && page.c.account.name ? page.c.account.name : page.tr("YouTube für UVE Player", "YouTube for UVE Player")
                    }
                    RowLayout {
                        spacing: 8
                        Rectangle {
                            implicitWidth: pill.implicitWidth + 18; implicitHeight: 22; radius: 11
                            color: Qt.rgba(0.2, 0.8, 0.4, 0.22)
                            Label {
                                id: pill; anchors.centerIn: parent; font.pixelSize: 11; font.bold: true; color: "#6ee59a"
                                text: page.c && page.c.loggedIn ? page.tr("● Google-Konto verbunden", "● Google account connected") : page.tr("● Bereit – ohne Anmeldung", "● Ready – no sign-in needed")
                            }
                        }
                        Label {
                            text: { var g = page.c ? page.c.libraryGen : 0
                                    var n = ((page.c ? page.c.get("localSubs") : []) || []).length
                                    return page.c && page.c.loggedIn ? (page.c.account ? page.c.account.handle || "" : "") : n + page.tr(" Abos im Plugin", " subscriptions in the plugin") }
                            color: Qt.rgba(1, 1, 1, 0.7); font.pixelSize: 12
                        }
                    }
                }
            }
            Label {
                Layout.fillWidth: true; wrapMode: Text.Wrap
                color: Qt.rgba(1, 1, 1, 0.75); font.pixelSize: 13
                text: page.tr("Öffne YouTube über Plugins → YouTube öffnen (Strg+Alt+Y). Trends, Suche, Kanäle und Playlists funktionieren sofort. Abonniere Kanäle direkt im Plugin (Kanal öffnen → Abonnieren) oder importiere unten deine YouTube-Abos.",
                              "Open YouTube via Plugins → Open YouTube (Ctrl+Alt+Y). Trending, search, channels and playlists work right away. Subscribe to channels inside the plugin (open a channel → Subscribe) or import your YouTube subscriptions below.")
            }
            Flow {
                Layout.fillWidth: true
                spacing: 8
                Button {
                    highlighted: true
                    text: page.tr("▶  YouTube öffnen", "▶  Open YouTube")
                    onClicked: page.c.openBrowser(page.cfg("startTab"))
                }
                Button {
                    visible: !(page.c && page.c.loggedIn)
                    text: page.tr("  G  Mit Google verbinden", "  G  Connect with Google")
                    onClicked: page.openLogin("login")
                }
                Button {
                    visible: !!(page.c && page.c.loggedIn)
                    text: page.tr("Google-Konto trennen", "Disconnect Google account")
                    onClicked: page.openLogin("logout")
                }
            }
        }
    }

    // ---- Abos -----------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Abos", "Subscriptions") }
    Card {
        pg: page
        Row2 {
            pg: page
            label: page.tr("Deine YouTube-Abos importieren", "Import your YouTube subscriptions")
            hint: page.tr("Dein Kanal als @name oder Kanal-Link. Deine Abos müssen öffentlich sein (YouTube → Einstellungen → Datenschutz → „Alle meine Abos privat halten“ aus). Danach zeigt „Playlists“ auch deine öffentlichen Playlists.",
                          "Your channel as @name or channel link. Your subscriptions must be public (YouTube → Settings → Privacy → “Keep all my subscriptions private” off). “Playlists” then also shows your public playlists.")
            TextField {
                id: handleField
                Layout.preferredWidth: 220
                text: page.cfg("channelHandle")
                placeholderText: "@deinkanal"
                selectByMouse: true
                onAccepted: importBtn.clicked()
            }
            Button {
                id: importBtn
                text: page.tr("Importieren", "Import")
                enabled: !page.importing && handleField.text.trim() !== ""
                onClicked: {
                    page.importing = true; page.importState = ""
                    page.c.importSubscriptions(handleField.text.trim(), function (ok, r) {
                        page.importing = false
                        page.importState = ok ? page.tr("✓ " + r.channel.title + ": " + r.total + " Abos gefunden, " + r.added + " neu übernommen.",
                                                        "✓ " + r.channel.title + ": " + r.total + " subscriptions found, " + r.added + " added.")
                                              : String(r)
                    })
                }
            }
        }
        Label {
            visible: page.importState !== "" || page.importing
            Layout.fillWidth: true; wrapMode: Text.Wrap; font.pixelSize: 12
            color: page.importing ? page.cMuted : page.importState.indexOf("✓") === 0 ? "#6ee59a" : (page.theme ? page.theme.error : "#ff6b6b")
            text: page.importing ? page.tr("Importiere …", "Importing …") : page.importState
        }
        // Abos im Plugin
        Flow {
            Layout.fillWidth: true
            spacing: 6
            Repeater {
                model: { var g = page.c ? page.c.libraryGen : 0; return ((page.c ? page.c.get("localSubs") : []) || []).slice(0, 60) }
                delegate: Rectangle {
                    required property var modelData
                    implicitWidth: chipRow.implicitWidth + 14; implicitHeight: 28; radius: 14
                    color: Qt.rgba(1, 1, 1, chipMouse.containsMouse ? 0.1 : 0.05)
                    Row {
                        id: chipRow
                        anchors.verticalCenter: parent.verticalCenter; x: 4; spacing: 6
                        Rectangle { width: 20; height: 20; radius: 10; clip: true; color: page.cPanel
                            Image { anchors.fill: parent; source: modelData.avatar || ""; fillMode: Image.PreserveAspectCrop; asynchronous: true; sourceSize.width: 40 } }
                        Label { text: modelData.title; color: page.cText; font.pixelSize: 12; anchors.verticalCenter: parent.verticalCenter }
                        Label { text: "✕"; color: chipMouse.containsMouse ? page.ytRed : page.cMuted; font.pixelSize: 11; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { id: chipMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: page.c.toggleSubscribe(modelData) }
                    ToolTip.text: page.tr("Abo beenden", "Unsubscribe"); ToolTip.visible: chipMouse.containsMouse; ToolTip.delay: 500
                }
            }
        }
        Slide {
            pg: page
            key: "subsFeedChannels"; from: 10; to: 150; step: 5; unit: ""
            label: page.tr("Kanäle im Abos-Feed", "Channels in the subscription feed")
            hint: page.tr("Die neuesten Videos so vieler Abos werden zusammengeführt (über RSS, kostet kaum Kontingent).", "The newest videos of this many subscriptions are merged (via RSS, uses hardly any quota).")
        }
    }

    // ---- Lokale Bibliothek --------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Verlauf, Später ansehen & Favoriten", "History, watch later & favourites") }
    Card {
        pg: page
        Toggle { pg: page; key: "historyEnabled"; label: page.tr("Verlauf speichern", "Keep history"); hint: page.tr("Videos, die du über das Plugin abspielst, erscheinen unter „Verlauf“.", "Videos you play through the plugin appear under “History”.") }
        RowLayout {
            Layout.fillWidth: true
            spacing: 8
            Label {
                Layout.fillWidth: true; color: page.cMuted; font.pixelSize: 12; wrapMode: Text.Wrap
                text: { var g = page.c ? page.c.libraryGen : 0
                        var n = function (k) { return ((page.c ? page.c.get(k) : []) || []).length }
                        return page.tr("Verlauf: " + n("history") + " · Später ansehen: " + n("watchLater") + " · Favoriten: " + n("favorites"),
                                       "History: " + n("history") + " · Watch later: " + n("watchLater") + " · Favourites: " + n("favorites")) }
            }
            Button { text: page.tr("Verlauf löschen", "Clear history"); onClicked: page.c.clearHistory() }
        }
    }

    // ---- Google-Konto ------------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Google-Konto", "Google account") }
    Card {
        pg: page
        Label {
            Layout.fillWidth: true; wrapMode: Text.Wrap; color: page.cMuted; font.pixelSize: 12
            text: page.tr("Optional: Verbinde dein Google-Konto, dann kommen Abos, „Mag ich“ und deine Playlists direkt von YouTube. Die Anmeldung läuft sicher in deinem Standardbrowser (OAuth 2.0 mit PKCE), das Plugin bekommt nur Lesezugriff.",
                          "Optional: connect your Google account to get subscriptions, liked videos and your playlists straight from YouTube. Sign-in happens securely in your default browser (OAuth 2.0 with PKCE); the plugin only gets read access.")
        }
        RowLayout {
            Button {
                visible: !(page.c && page.c.loggedIn)
                highlighted: true
                text: page.tr("  G  Mit Google verbinden  ", "  G  Connect with Google  ")
                onClicked: page.openLogin("login")
            }
            Button {
                visible: !!(page.c && page.c.loggedIn)
                text: page.tr("Konto wechseln", "Switch account")
                onClicked: page.openLogin("login")
            }
            Button {
                visible: !!(page.c && page.c.loggedIn)
                text: page.tr("Verbindung trennen", "Disconnect")
                onClicked: page.openLogin("logout")
            }
        }
    }

    // Anmeldung im Standardbrowser (Code-Anzeige)
    Loader {
        id: loginLoader
        Layout.fillWidth: true
        Layout.preferredHeight: page.showLogin ? Math.max(380, item ? item.implicitHeight : 0) : 0
        visible: page.showLogin
        Connections {
            target: loginLoader.item
            ignoreUnknownSignals: true
            function onOpenSettings() { page.showLogin = false }
            function onFinished(loggedIn) { page.showLogin = false; page.refreshStatus() }
            function onCancelled() { page.showLogin = false }
        }
    }

    // ---- Kacheln & Hover --------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Kacheln & Hover-Rahmen", "Tiles & hover frame") }
    Card { pg: page;
        RowLayout {
            Layout.fillWidth: true
            spacing: 18
            // Live-Vorschau
            ColumnLayout {
                Layout.alignment: Qt.AlignTop
                spacing: 6
                Label { text: page.tr("Vorschau – Maus drüber!", "Preview – hover me!"); color: page.cMuted; font.pixelSize: 12 }
                Item {
                    implicitWidth: 240; implicitHeight: demo.implicitHeight + 14
                    VideoTile {
                        id: demo
                        y: 8
                        width: 240
                        preview: true
                        controller: page.c
                        theme: page.theme
                        hue: page.hue
                        item: ({ type: "video", id: "aqz-KE-bpKQ", title: page.tr("Big Buck Bunny – so sieht deine Kachel aus", "Big Buck Bunny – this is how your tile looks"),
                                 channel: "Blender", views: page.tr("12 Mio. Aufrufe", "12M views"), age: page.tr("vor 3 Jahren", "3 years ago"), duration: "10:35", progress: 35 })
                    }
                }
            }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.alignment: Qt.AlignTop
                spacing: 10
                Label { text: page.tr("Rahmenfarbe", "Frame colour"); color: page.cText }
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: [
                            { c: "#ff0033", n: "YouTube" }, { c: "#ff8a1f", n: "UVE" }, { c: "#4da3ff", n: "Blau" }, { c: "#2ee6a6", n: "Mint" },
                            { c: "#b46bff", n: "Lila" }, { c: "#ffd23f", n: "Gold" }, { c: "#ff5fa2", n: "Pink" }, { c: "#ffffff", n: "Weiß" }
                        ]
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool sel: page.cfg("hoverStyle") === "solid" && String(page.cfg("hoverColor")).toLowerCase() === modelData.c
                            width: 30; height: 30; radius: 15
                            color: modelData.c
                            border.width: sel ? 3 : 1
                            border.color: sel ? page.cText : Qt.rgba(0, 0, 0, 0.4)
                            scale: swMouse.containsMouse ? 1.15 : 1
                            Behavior on scale { NumberAnimation { duration: 120 } }
                            Label { anchors.centerIn: parent; visible: parent.sel; text: "✓"; color: modelData.c === "#ffffff" || modelData.c === "#ffd23f" ? "black" : "white"; font.bold: true }
                            MouseArea { id: swMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: { page.put("hoverStyle", "solid"); page.put("hoverColor", modelData.c) } }
                            ToolTip.text: modelData.n; ToolTip.visible: swMouse.containsMouse; ToolTip.delay: 300
                        }
                    }
                    // Regenbogen
                    Rectangle {
                        readonly property bool sel: page.cfg("hoverStyle") === "rainbow"
                        width: 30; height: 30; radius: 15
                        border.width: sel ? 3 : 1; border.color: sel ? page.cText : Qt.rgba(0, 0, 0, 0.4)
                        gradient: Gradient {
                            GradientStop { position: 0; color: Qt.hsla(page.hue, 0.9, 0.6, 1) }
                            GradientStop { position: 0.5; color: Qt.hsla((page.hue + 0.33) % 1, 0.9, 0.6, 1) }
                            GradientStop { position: 1; color: Qt.hsla((page.hue + 0.66) % 1, 0.9, 0.6, 1) }
                        }
                        MouseArea { id: rbMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: page.put("hoverStyle", "rainbow") }
                        ToolTip.text: page.tr("Regenbogen (animiert)", "Rainbow (animated)"); ToolTip.visible: rbMouse.containsMouse
                    }
                    // Zweifarbig
                    Rectangle {
                        readonly property bool sel: page.cfg("hoverStyle") === "gradient"
                        width: 30; height: 30; radius: 15
                        color: "transparent"
                        border.width: sel ? 3 : 1; border.color: sel ? page.cText : Qt.rgba(0, 0, 0, 0.4)
                        Rectangle { anchors.fill: parent; anchors.margins: 4; radius: width / 2; color: "transparent"; border.width: 4; border.color: Qt.hsla(page.hue, 0.9, 0.6, 1)
                            Rectangle { anchors.fill: parent; anchors.margins: 4; radius: width / 2; color: Qt.hsla((page.hue + 0.33) % 1, 0.9, 0.6, 1) } }
                        MouseArea { id: gdMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: page.put("hoverStyle", "gradient") }
                        ToolTip.text: page.tr("Zweifarbig, wandernd", "Two-tone, shifting"); ToolTip.visible: gdMouse.containsMouse
                    }
                    // eigene Farbe
                    Rectangle {
                        width: hexField.implicitWidth + 16; height: 30; radius: 15
                        color: Qt.rgba(0, 0, 0, 0.25); border.color: page.cLine
                        TextField {
                            id: hexField
                            anchors.centerIn: parent
                            width: 84; background: null; color: page.cText; font.pixelSize: 12
                            text: page.cfg("hoverColor")
                            validator: RegularExpressionValidator { regularExpression: /#[0-9a-fA-F]{0,8}/ }
                            onEditingFinished: if (/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(text)) { page.put("hoverStyle", "solid"); page.put("hoverColor", text.toLowerCase()) }
                        }
                    }
                }
                Slide { pg: page; key: "hoverWidth"; from: 1; to: 8; unit: " px"; label: page.tr("Rahmenstärke", "Frame width") }
                Slide { pg: page; key: "tileRadius"; from: 0; to: 24; unit: " px"; label: page.tr("Ecken-Rundung", "Corner radius") }
                Slide { pg: page; key: "tileWidth"; from: 180; to: 420; step: 10; unit: " px"; label: page.tr("Kachelgröße", "Tile size"); hint: page.tr("Breite einer Kachel; die Anzahl der Spalten passt sich dem Fenster an.", "Width of a tile; the number of columns follows the window.") }
            }
        }
        Rectangle { Layout.fillWidth: true; height: 1; color: page.cLine }
        GridLayout {
            Layout.fillWidth: true
            columns: page.width > 640 ? 2 : 1
            columnSpacing: 24; rowSpacing: 8
            Toggle { pg: page; key: "hoverGlow"; label: page.tr("Leuchten um den Rahmen", "Glow around the frame") }
            Toggle { pg: page; key: "hoverZoom"; label: page.tr("Leicht vergrößern", "Slight zoom") }
            Toggle { pg: page; key: "hoverLift"; label: page.tr("Anheben", "Lift up") }
            Toggle { pg: page; key: "showProgress"; label: page.tr("Fortschritt angesehener Videos", "Progress of watched videos") }
            Toggle { pg: page; key: "showAvatars"; label: page.tr("Kanalbilder anzeigen", "Show channel pictures") }
            Toggle { pg: page; key: "compactSidebar"; label: page.tr("Schmale Navigationsleiste", "Narrow navigation bar") }
        }
        Choice { pg: page;
            key: "thumbQuality"; label: page.tr("Vorschaubild-Qualität", "Thumbnail quality")
            options: [{ v: "mq", de: "Schnell (320 px)", en: "Fast (320 px)" }, { v: "hq", de: "Standard (480 px)", en: "Standard (480 px)" }, { v: "max", de: "Maximal (HD)", en: "Maximum (HD)" }]
        }
    }

    // ---- Inhalte ------------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Inhalte", "Content") }
    Card { pg: page;
        Choice { pg: page;
            key: "startTab"; label: page.tr("Startseite beim Öffnen", "Start page when opening")
            options: [{ v: "home", de: "Trends", en: "Trending" }, { v: "subs", de: "Abos", en: "Subscriptions" }, { v: "channels", de: "Kanäle", en: "Channels" },
                      { v: "history", de: "Verlauf", en: "History" }, { v: "later", de: "Später ansehen", en: "Watch later" }, { v: "liked", de: "Favoriten / Mag ich", en: "Favourites / Liked" },
                      { v: "playlists", de: "Playlists", en: "Playlists" }]
        }
        Toggle { pg: page; key: "hideShorts"; label: page.tr("Shorts ausblenden", "Hide Shorts"); hint: page.tr("Hochformat-Clips aus allen Listen entfernen.", "Remove portrait clips from all lists.") }
        Toggle { pg: page; key: "hideLive"; label: page.tr("Livestreams ausblenden", "Hide live streams") }
        Toggle { pg: page; key: "hideWatched"; label: page.tr("Fertig angesehene ausblenden", "Hide finished videos"); hint: page.tr("Videos, die zu mehr als 90 % angesehen wurden.", "Videos watched more than 90 %.") }
        Row2 { pg: page;
            label: page.tr("Ausgeblendete Kanäle", "Hidden channels")
            hint: page.tr("Kanalnamen, durch Komma getrennt. Auch per Rechtsklick auf eine Kachel → Kanal ausblenden.", "Channel names separated by commas. Also via right-click on a tile → Hide channel.")
            TextField {
                Layout.preferredWidth: 280
                text: page.cfg("blockedChannels")
                placeholderText: page.tr("z. B. Kanal A, Kanal B", "e.g. Channel A, Channel B")
                onEditingFinished: page.put("blockedChannels", text)
            }
        }
    }

    // ---- Wiedergabe -----------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Wiedergabe", "Playback") }
    Card { pg: page;
        Choice { pg: page;
            key: "clickAction"; label: page.tr("Klick auf ein Video", "Click on a video")
            hint: page.tr("Die Knöpfe ⏭ und + auf der Kachel und das Rechtsklick-Menü bieten immer alle Möglichkeiten.", "The ⏭ and + buttons on the tile and the right-click menu always offer every option.")
            options: [{ v: "play", de: "Sofort abspielen", en: "Play now" }, { v: "next", de: "Als Nächstes abspielen", en: "Play next" }, { v: "queue", de: "Zur Playlist hinzufügen", en: "Add to playlist" }]
        }
        Toggle { pg: page; key: "closeOnPlay"; label: page.tr("Fenster beim Abspielen schließen", "Close the window when playing") }
    }

    // ---- Fenster ----------------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Fenster", "Window") }
    Card { pg: page;
        Choice { pg: page;
            key: "modalScope"; label: page.tr("Bereich", "Area")
            hint: page.tr("„Nur Video“ lässt Steuerleiste und Seitenleiste bedienbar.", "“Video only” keeps the control bar and sidebar usable.")
            options: [{ v: "player", de: "Ganzer Player", en: "Whole player" }, { v: "video", de: "Nur Video", en: "Video only" }]
        }
        Choice { pg: page;
            key: "modalMode"; label: page.tr("Modus", "Mode")
            options: [{ v: "movable", de: "Verschiebbar & größenveränderbar", en: "Movable & resizable" }, { v: "fixed", de: "Fest, größenveränderbar", en: "Fixed, resizable" }, { v: "fill", de: "Ganzen Bereich füllen", en: "Fill the whole area" }]
        }
        Row2 { pg: page;
            label: page.tr("Fenstergröße", "Window size")
            hint: page.tr("Am rechten/unteren Rand oder an der Ecke des Fensters ziehen; Doppelklick auf den Rand setzt zurück.", "Drag the right/bottom edge or the corner of the window; double-click an edge to reset.")
            Label { text: page.cfg("modalWidth") + " × " + page.cfg("modalHeight"); color: page.cMuted }
            Button { text: page.tr("Zurücksetzen", "Reset"); onClicked: { page.put("modalWidth", 1120); page.put("modalHeight", 720) } }
        }
    }

    // ---- Region -----------------------------------------------------------------------------------
    SectionTitle { pg: page; text: page.tr("Sprache & Region", "Language & region") }
    Card { pg: page;
        Choice { pg: page;
            key: "hl"; label: page.tr("Sprache der Inhalte", "Content language")
            options: [{ v: "", de: "Wie der Player", en: "Same as the player" }, { v: "de", de: "Deutsch", en: "German" }, { v: "en", de: "Englisch", en: "English" },
                      { v: "es", de: "Spanisch", en: "Spanish" }, { v: "it", de: "Italienisch", en: "Italian" }, { v: "pl", de: "Polnisch", en: "Polish" },
                      { v: "tr", de: "Türkisch", en: "Turkish" }, { v: "el", de: "Griechisch", en: "Greek" }, { v: "fr", de: "Französisch", en: "French" }]
        }
        Choice { pg: page;
            key: "gl"; label: page.tr("Land für Empfehlungen", "Country for recommendations")
            options: [{ v: "", de: "Automatisch", en: "Automatic" }, { v: "DE", de: "Deutschland", en: "Germany" }, { v: "AT", de: "Österreich", en: "Austria" },
                      { v: "CH", de: "Schweiz", en: "Switzerland" }, { v: "US", de: "USA", en: "United States" }, { v: "GB", de: "Großbritannien", en: "United Kingdom" },
                      { v: "GR", de: "Griechenland", en: "Greece" }, { v: "TR", de: "Türkei", en: "Turkey" }, { v: "PL", de: "Polen", en: "Poland" }]
        }
    }

    Item { Layout.preferredHeight: 10 }
}
