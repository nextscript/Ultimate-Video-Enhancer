import QtQml

// YouTubes eigene Web-Schnittstelle (InnerTube) – ohne API-Key, ohne Kontingent, ohne Anmeldung.
// Für die Suche (die über die Data API 100 Einheiten kostet) und als Ersatz, wenn das API-Kontingent aufgebraucht ist.
QtObject {
    id: it
    property var controller
    property string clientVersion: "2.20251118.01.00"

    function post(endpoint, body, cb) {
        var x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            var j = null
            try { j = JSON.parse(x.responseText) } catch (e) { j = null }
            if (x.status === 200 && j) cb(true, j)
            else cb(false, "YouTube HTTP " + x.status)
        }
        x.open("POST", "https://www.youtube.com/youtubei/v1/" + endpoint + "?prettyPrint=false")
        x.setRequestHeader("Content-Type", "application/json")
        x.setRequestHeader("X-Youtube-Client-Name", "1")
        x.setRequestHeader("X-Youtube-Client-Version", clientVersion)
        body.context = { client: { clientName: "WEB", clientVersion: clientVersion, hl: controller.hl(), gl: controller.gl() || regionOf() } }
        x.send(JSON.stringify(body))
    }
    function regionOf() { var l = controller.lang; return l === "en" ? "US" : l === "el" ? "GR" : l.toUpperCase() }

    // ---- Befehle -------------------------------------------------------------------------------
    function search(query, params, continuation, cb) {
        var b = continuation ? { continuation: continuation } : { query: query }
        if (params && !continuation) b.params = params
        post("search", b, function (ok, j) { cb(ok, ok ? extract(j) : j) })
    }
    function browse(browseId, params, continuation, cb) {
        var b = continuation ? { continuation: continuation } : { browseId: browseId }
        if (params && !continuation) b.params = params
        post("browse", b, function (ok, j) { cb(ok, ok ? extract(j) : j) })
    }
    // ähnliche Videos zu einem Video
    function related(videoId, cb) {
        post("next", { videoId: videoId }, function (ok, j) {
            if (!ok) { cb(false, j); return }
            var r = extract(j && j.contents && j.contents.twoColumnWatchNextResults ? j.contents.twoColumnWatchNextResults.secondaryResults : j)
            cb(true, r.items.filter(function (i) { return i.id !== videoId }))
        })
    }

    // ---- Auswertung (Renderer der YouTube-Webseite -> einheitliche Kacheln) --------------------
    function txt(t) {
        if (!t) return ""
        if (typeof t === "string") return t
        if (t.simpleText !== undefined && t.simpleText !== null) return String(t.simpleText)
        if (t.runs) return t.runs.map(function (r) { return r.text }).join("")
        if (t.content !== undefined && t.content !== null) return String(t.content)
        return ""
    }
    function deep(o, key, limit) {
        if (!o || typeof o !== "object") return undefined
        var q = [o], n = 0, max = limit || 4000
        while (q.length && n++ < max) {
            var c = q.shift()
            if (!c || typeof c !== "object") continue
            if (!Array.isArray(c) && Object.prototype.hasOwnProperty.call(c, key)) return c[key]
            for (var k in c) { var v = c[k]; if (v && typeof v === "object") q.push(v) }
        }
        return undefined
    }
    function deepAll(o, key, out, depth) {
        out = out || []
        depth = depth || 0
        if (!o || typeof o !== "object" || depth > 40) return out
        if (Array.isArray(o)) { for (var i = 0; i < o.length; i++) deepAll(o[i], key, out, depth + 1); return out }
        for (var k in o) {
            if (k === key) out.push(o[k])
            else if (o[k] && typeof o[k] === "object") deepAll(o[k], key, out, depth + 1)
        }
        return out
    }
    function fix(u) { return !u ? "" : (u.indexOf("//") === 0 ? "https:" + u : u) }
    function thumbs(arr, last) { if (!arr || !arr.length) return ""; return fix((last ? arr[arr.length - 1] : arr[0]).url) }
    function browseIdOf(o) { var b = deep(o, "browseEndpoint", 600); return b && b.browseId ? b.browseId : "" }

    function fromVideoRenderer(v) {
        var id = v.videoId
        if (!id) return null
        var owner = v.ownerText || v.shortBylineText || v.longBylineText
        var item = { type: "video", id: id, title: txt(v.title) || txt(v.headline), channel: txt(owner), channelId: browseIdOf(owner),
                     duration: txt(v.lengthText), views: txt(v.shortViewCountText) || txt(v.viewCountText),
                     age: txt(v.publishedTimeText), live: false, short: false, progress: 0, avatar: "" }
        var ct = v.channelThumbnailSupportedRenderers && v.channelThumbnailSupportedRenderers.channelThumbnailWithLinkRenderer
        item.avatar = thumbs(ct && ct.thumbnail && ct.thumbnail.thumbnails) || thumbs(v.channelThumbnail && v.channelThumbnail.thumbnails)
        ;(v.thumbnailOverlays || []).forEach(function (o) {
            var s = o.thumbnailOverlayTimeStatusRenderer
            if (s) {
                if (!item.duration) item.duration = txt(s.text)
                if (s.style === "LIVE") item.live = true
                if (s.style === "SHORTS") item.short = true
            }
        })
        ;(v.badges || []).forEach(function (b) { var m = b.metadataBadgeRenderer; if (m && /LIVE/.test(m.style || "")) item.live = true })
        if (v.videoInfo && !item.views) { var parts = txt(v.videoInfo).split(/\s+•\s+/); item.views = parts[0] || ""; item.age = parts[1] || item.age }
        return item
    }
    function fromLockup(v) {
        var meta = v.metadata && v.metadata.lockupMetadataViewModel
        if (!meta) return null
        var rows = deep(meta, "metadataRows", 200) || []
        var parts = rows.map(function (r) { return (r.metadataParts || []).map(function (p) { return p.text ? txt(p.text) : "" }).filter(Boolean) })
        var img = v.contentImage || {}
        var tvm = img.thumbnailViewModel || deep(img, "thumbnailViewModel", 200) || {}
        var badges = deepAll(img, "thumbnailBadgeViewModel")
        var badgeText = badges.map(function (b) { return b.text || "" }).filter(Boolean)
        var live = badges.some(function (b) { return /LIVE/.test(b.badgeStyle || "") })
        var avatarVm = deep(meta, "avatarViewModel", 200)
        var type = v.contentType || ""
        var base = { id: v.contentId, title: txt(meta.title), channel: (parts[0] && parts[0][0]) || "", channelId: browseIdOf(meta),
                     avatar: thumbs(avatarVm && avatarVm.image && avatarVm.image.sources), thumb: thumbs(tvm.image && tvm.image.sources, true) }
        if (/PLAYLIST|PODCAST/.test(type)) { base.type = "playlist"; base.count = badgeText.join(" · "); base.info = (parts[1] || []).join(" · "); return base }
        if (/CHANNEL/.test(type)) { base.type = "channel"; return base }
        base.type = "video"
        // Kanalseiten: nur eine Zeile (Aufrufe · Alter), kein Kanalname
        if (parts.length === 1 && !base.channelId) { parts = [[""], parts[0]]; base.channel = "" }
        base.duration = badgeText.filter(function (t) { return /\d:\d/.test(t) })[0] || ""
        base.live = live
        base.views = (parts[1] && parts[1][0]) || ""
        base.age = (parts[1] && parts[1][1]) || ""
        base.progress = 0; base.short = false; base.thumb = ""
        return base
    }
    function fromShortsLockup(v) {
        var ep = deep(v, "reelWatchEndpoint", 300)
        var id = ep && ep.videoId
        if (!id) return null
        var om = v.overlayMetadata || {}
        return { type: "video", id: id, title: txt(om.primaryText) || v.accessibilityText || "", views: txt(om.secondaryText), short: true, channel: "", duration: "", age: "", progress: 0 }
    }
    function fromChannel(v) {
        if (!v.channelId) return null
        return { type: "channel", id: v.channelId, title: txt(v.title), avatar: thumbs(v.thumbnail && v.thumbnail.thumbnails, true),
                 info: [txt(v.subscriberCountText), txt(v.videoCountText)].filter(Boolean).join(" · ") }
    }
    function fromPlaylist(v) {
        if (!v.playlistId) return null
        var th = v.thumbnails && v.thumbnails[0] && v.thumbnails[0].thumbnails
        return { type: "playlist", id: v.playlistId, title: txt(v.title), channel: txt(v.shortBylineText || v.longBylineText),
                 thumb: thumbs(th || (v.thumbnail && v.thumbnail.thumbnails), true), count: txt(v.videoCountShortText || v.videoCountText || v.thumbnailText), info: "" }
    }

    readonly property var skip: ({ adSlotRenderer: 1, promotedSparklesWebRenderer: 1, frameworkUpdates: 1, menu: 1, topbar: 1, sidebar: 1 })
    function extract(data) {
        var items = [], seen = {}, cont = ""
        function add(i) {
            if (!i || !i.id) return
            var k = i.type + ":" + i.id
            if (seen[k]) return
            seen[k] = 1; items.push(i)
        }
        function walk(o, depth) {
            if (!o || typeof o !== "object" || depth > 60) return
            if (Array.isArray(o)) { for (var i = 0; i < o.length; i++) walk(o[i], depth + 1); return }
            for (var k in o) {
                var v = o[k]
                if (!v || typeof v !== "object" || it.skip[k]) continue
                if (k === "videoRenderer" || k === "gridVideoRenderer" || k === "compactVideoRenderer" || k === "playlistVideoRenderer") { add(fromVideoRenderer(v)); continue }
                if (k === "lockupViewModel") { add(fromLockup(v)); continue }
                if (k === "shortsLockupViewModel" || k === "reelItemRenderer") { add(k === "reelItemRenderer" ? (v.videoId ? { type: "video", id: v.videoId, title: txt(v.headline), short: true, channel: "", duration: "", views: txt(v.viewCountText), age: "", progress: 0 } : null) : fromShortsLockup(v)); continue }
                if (k === "channelRenderer" || k === "gridChannelRenderer") { add(fromChannel(v)); continue }
                if (k === "playlistRenderer" || k === "gridPlaylistRenderer") { add(fromPlaylist(v)); continue }
                if (k === "continuationItemRenderer") { var cmd = deep(v, "continuationCommand", 200); if (cmd && cmd.token && !cont) cont = cmd.token; continue }
                walk(v, depth + 1)
            }
        }
        walk(data, 0)
        var md = data && data.metadata
        var title = (md && md.channelMetadataRenderer && md.channelMetadataRenderer.title) || (md && md.playlistMetadataRenderer && md.playlistMetadataRenderer.title) || ""
        if (!title) {
            var ph = deep(data && data.header, "pageHeaderViewModel", 300)
            if (ph) title = txt(ph.title && (ph.title.dynamicTextViewModel ? ph.title.dynamicTextViewModel.text : ph.title))
        }
        var avatar = md && md.channelMetadataRenderer && md.channelMetadataRenderer.avatar ? thumbs(md.channelMetadataRenderer.avatar.thumbnails) : ""
        if (avatar) items.forEach(function (i) { if (i.type === "video" && !i.avatar) i.avatar = avatar })
        return { items: items, continuation: cont, title: title, avatar: avatar }
    }
}
