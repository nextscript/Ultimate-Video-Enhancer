import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Plugin-Fenster "YouTube": Empfohlen, Abos, Kanäle, Verlauf, Später ansehen, Mag ich, Playlists, Suche.
Item {
    id: page
    property var theme
    property var plugin
    property var controller
    property var modal

    readonly property var c: controller
    function tr(de, en) { return c ? c.t(de, en) : de }
    function cfg(k) { return c ? c.get(k) : null }

    readonly property color cText: theme ? theme.text : "#e6e8eb"
    readonly property color cMuted: theme ? theme.muted : "#8b93a1"
    readonly property color cPanel: theme ? theme.panel : "#14171c"
    readonly property color cPanel2: theme ? theme.panel2 : "#1b1f26"
    readonly property color cLine: theme ? theme.line : "#262b34"
    readonly property color ytRed: "#ff0033"
    readonly property real bgAlpha: modal ? modal.backgroundAlpha : 1

    implicitWidth: 1120
    implicitHeight: 684

    // ---- Ansichten -----------------------------------------------------------------------------
    readonly property var tabs: [
        { key: "home", icon: "🔥", de: "Trends", en: "Trending", browseId: "FEwhat_to_watch", login: false },
        { key: "subs", icon: "▤", de: "Abos", en: "Subscriptions", browseId: "FEsubscriptions", login: false },
        { key: "channels", icon: "◉", de: "Kanäle", en: "Channels", browseId: "FEchannels", login: false },
        { key: "history", icon: "↺", de: "Verlauf", en: "History", browseId: "FEhistory", login: false },
        { key: "later", icon: "◷", de: "Später ansehen", en: "Watch later", browseId: "VLWL", login: false },
        { key: "liked", icon: "♥", de: "Mag ich", en: "Liked videos", browseId: "VLLL", login: false },
        { key: "playlists", icon: "≡", de: "Playlists", en: "Playlists", browseId: "FEplaylist_aggregation", login: false }
    ]
    readonly property var searchFilters: [
        { de: "Alle", en: "All", params: "" },
        { de: "Videos", en: "Videos", params: "EgIQAQ==" },
        { de: "Live", en: "Live", params: "EgJAAQ==" },
        { de: "Kanäle", en: "Channels", params: "EgIQAg==" },
        { de: "Playlists", en: "Playlists", params: "EgIQAw==" }
    ]

    property var view: ({ kind: "tab", key: "home" })   // {kind:"tab",key} | {kind:"search",query,filter} | {kind:"browse",browseId,params,title}
    property var history: []
    property var _items: []
    property string continuation: ""
    property bool loading: false
    property bool loadingMore: false
    property string error: ""
    property string viewTitle: ""
    property int _req: 0
    property bool showLogin: false
    property string loginMode: "login"
    property real hue: 0

    NumberAnimation on hue { from: 0; to: 1; duration: 4000; loops: Animation.Infinite; running: page.cfg("hoverStyle") !== "solid" }

    function tabLabel(t) {
        if (t.key === "liked" && !(c && c.loggedIn)) return tr("Favoriten", "Favourites")
        return tr(t.de, t.en)
    }
    function tabByKey(k) { for (var i = 0; i < tabs.length; i++) if (tabs[i].key === k) return tabs[i]; return tabs[0] }
    function bridge() { return c ? c.api : null }

    onCChanged: start()
    Component.onCompleted: start()
    property bool _started: false
    function start() {
        if (_started || !c) return
        _started = true
        var d = modal && modal.data
        var tab = d && d.tab ? d.tab : cfg("startTab")
        view = { kind: "tab", key: tab }
        createBridge()
        if (d && d.focusSearch) searchField.forceActiveFocus()
    }
    Connections {
        target: page.modal
        ignoreUnknownSignals: true
        function onDataChanged() {
            var d = page.modal.data
            if (!d || d.resize) return
            if (d.tab) page.navigate({ kind: "tab", key: d.tab }, true)
            if (d.focusSearch) searchField.forceActiveFocus()
        }
    }
    Connections {
        target: page.c
        ignoreUnknownSignals: true
        function onSessionGenChanged() { page.createBridge() }
        function onLibraryGenChanged() {
            if (page.view.kind !== "tab") return
            var k = page.view.key
            if (k === "history" || k === "later" || (!page.c.loggedIn && (k === "liked" || k === "channels" || k === "subs"))) libReload.restart()
        }
    }
    Timer { id: libReload; interval: 250; onTriggered: page.reload() }

    function createBridge() {
        reload()
    }
    readonly property bool sourceAvailable: !!(c && c.api)

    function navigate(v, replace) {
        if (!replace) history = history.concat([view])
        view = v
        showLogin = false
        reload()
    }
    function goBack() {
        if (!history.length) return
        var h = history.slice(); view = h.pop(); history = h
        reload()
    }

    function requestFor(v, cont) {
        if (v.kind === "search") return { name: "search", args: cont ? { continuation: cont } : { query: v.query, params: v.filter || "" } }
        if (v.kind === "browse") return { name: "browse", args: cont ? { continuation: cont } : { browseId: v.browseId, params: v.params || "" } }
        var t = tabByKey(v.key)
        return { name: "browse", args: cont ? { continuation: cont } : { browseId: t.browseId } }
    }
    readonly property bool needsLogin: false

    function reload() {
        var b = bridge()
        _items = []; tileModel.clear(); continuation = ""; error = ""
        viewTitle = view.kind === "tab" ? tabLabel(tabByKey(view.key))
                  : view.kind === "search" ? tr("Suche: ", "Search: ") + view.query : (view.title || "")
        grid.contentY = 0
        if (!b) { loading = false; return }
        loading = true
        var id = ++_req
        b.request("status", {}, function (ok, data) {
            if (ok && c) c.setStatus(!!data.loggedIn, data.account)
            if (id !== page._req) return
            if (page.needsLogin) { page.loading = false; return }
            var r = page.requestFor(page.view, "")
            b.request(r.name, r.args, function (ok2, data2) {
                if (id !== page._req) return
                page.loading = false
                if (!ok2) { page.error = page.needsLogin ? "" : String(data2); return }
                if (data2.title && page.view.kind === "browse") page.viewTitle = data2.title
                page.continuation = data2.continuation || ""
                page.appendItems(data2.items || [])
                page.fillIfShort()
            })
        })
    }
    function loadMore() {
        var b = bridge()
        if (!b || !continuation || loading || loadingMore) return
        loadingMore = true
        var id = _req
        var r = requestFor(view, continuation)
        b.request(r.name, r.args, function (ok, data) {
            if (id !== page._req) return
            page.loadingMore = false
            if (!ok) { page.continuation = ""; return }
            page.continuation = (data.continuation && data.continuation !== page.continuation) ? data.continuation : ""
            page.appendItems(data.items || [])
            page.fillIfShort()
        })
    }
    function fillIfShort() { if (continuation && grid.contentHeight < grid.height + 200) Qt.callLater(loadMore) }

    function blocked() {
        return String(cfg("blockedChannels") || "").split(/[,;\n]/).map(function (s) { return s.trim().toLowerCase() }).filter(Boolean)
    }
    function appendItems(list) {
        var bl = blocked(), known = {}
        for (var k = 0; k < _items.length; k++) known[_items[k].type + _items[k].id] = 1
        for (var i = 0; i < list.length; i++) {
            var it = list[i]
            if (!it || known[it.type + it.id]) continue
            if (it.type === "video") {
                if (cfg("hideShorts") && it.short) continue
                if (cfg("hideLive") && it.live) continue
                if (cfg("hideWatched") && it.progress >= 90) continue
            }
            if (bl.length && it.channel && bl.indexOf(String(it.channel).toLowerCase()) >= 0) continue
            known[it.type + it.id] = 1
            _items.push(it)
            tileModel.append({ idx: _items.length - 1 })
        }
    }

    function activate(it, action) {
        if (!it) return
        if (it.type === "video") c.playVideos([it], action)
        else if (it.type === "channel") navigate({ kind: "browse", browseId: it.id, params: "EgZ2aWRlb3PyBgQKAjoA", title: it.title })
        else if (it.type === "playlist") {
            if (/^RD/.test(it.id)) {   // Mix: direkt als YouTube-Liste abspielen
                plugin.call("playlist.add", { urls: ["https://www.youtube.com/playlist?list=" + it.id], titles: [it.title], play: true })
                if (cfg("closeOnPlay")) modal.close()
            } else navigate({ kind: "browse", browseId: "VL" + it.id, title: it.title })
        }
    }
    function playAll(action) { c.playVideos(_items, action) }


    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(page.cPanel.r, page.cPanel.g, page.cPanel.b, page.bgAlpha)
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // ---- Seitenleiste ------------------------------------------------------------------------
        Rectangle {
            id: side
            readonly property bool compact: page.cfg("compactSidebar") || page.width < 820
            Layout.fillHeight: true
            Layout.preferredWidth: compact ? 64 : 212
            color: Qt.rgba(page.cPanel2.r, page.cPanel2.g, page.cPanel2.b, page.bgAlpha)
            Behavior on Layout.preferredWidth { NumberAnimation { duration: 160 } }

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 10
                spacing: 4

                // Logo
                RowLayout {
                    Layout.fillWidth: true
                    Layout.bottomMargin: 8
                    spacing: 8
                    Rectangle {
                        implicitWidth: 38; implicitHeight: 27; radius: 7
                        color: page.ytRed
                        Label { anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; text: "▶"; color: "white"; font.pixelSize: 13 }
                    }
                    Label { visible: !side.compact; text: "YouTube"; color: page.cText; font.pixelSize: 18; font.bold: true; font.letterSpacing: -0.5 }
                    Item { Layout.fillWidth: true }
                }

                Repeater {
                    model: page.tabs
                    delegate: ItemDelegate {
                        id: navItem
                        required property var modelData
                        readonly property bool current: page.view.kind === "tab" && page.view.key === modelData.key
                        Layout.fillWidth: true
                        implicitHeight: 38
                        onClicked: page.navigate({ kind: "tab", key: modelData.key }, false)
                        ToolTip.text: page.tabLabel(modelData); ToolTip.visible: side.compact && hovered
                        background: Rectangle {
                            radius: 9
                            color: navItem.current ? Qt.rgba(1, 0, 0.2, 0.16) : navItem.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent"
                            Rectangle { visible: navItem.current; width: 3; height: 18; radius: 2; color: page.ytRed; anchors.verticalCenter: parent.verticalCenter }
                        }
                        contentItem: RowLayout {
                            spacing: 12
                            Label { text: navItem.modelData.icon; color: navItem.current ? page.ytRed : page.cText; font.pixelSize: 16
                                    Layout.preferredWidth: 22; horizontalAlignment: Text.AlignHCenter }
                            Label { visible: !side.compact; Layout.fillWidth: true; text: page.tabLabel(navItem.modelData)
                                    color: page.cText; font.weight: navItem.current ? Font.DemiBold : Font.Normal; elide: Text.ElideRight }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                // Konto
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: side.compact ? 48 : 64
                    radius: 12
                    color: Qt.rgba(1, 1, 1, accMouse.containsMouse ? 0.08 : 0.04)
                    border.color: page.cLine
                    RowLayout {
                        anchors.fill: parent; anchors.margins: 8
                        spacing: 8
                        Rectangle {
                            implicitWidth: 34; implicitHeight: 34; radius: 17
                            color: page.c && page.c.loggedIn ? "#3a3f4a" : "transparent"
                            border.color: page.c && page.c.loggedIn ? page.ytRed : page.cLine; border.width: 2
                            clip: true
                            Image { anchors.fill: parent; anchors.margins: 2; source: page.c && page.c.account && page.c.account.photo ? page.c.account.photo : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true }
                            Label { anchors.centerIn: parent; visible: !(page.c && page.c.account && page.c.account.photo); text: page.c && page.c.loggedIn ? "G" : "▶"; color: page.c && page.c.loggedIn ? page.cText : page.ytRed; font.bold: true }
                        }
                        ColumnLayout {
                            visible: !side.compact
                            Layout.fillWidth: true
                            spacing: 0
                            Label { Layout.fillWidth: true; elide: Text.ElideRight; color: page.cText; font.weight: Font.DemiBold; font.pixelSize: 13
                                    text: page.c && page.c.loggedIn ? (page.c.account && page.c.account.name ? page.c.account.name : page.tr("Verbunden", "Connected")) : page.tr("Ohne Anmeldung", "No sign-in needed") }
                            Label { Layout.fillWidth: true; elide: Text.ElideRight; color: page.c && (page.c.loggedIn || !page.c.oauthConfigured) ? page.cMuted : page.ytRed; font.pixelSize: 11
                                    text: page.c && page.c.loggedIn ? (page.c.account && page.c.account.handle ? page.c.account.handle : "")
                                        : page.c && page.c.oauthConfigured ? page.tr("Google-Konto verbinden →", "Connect Google account →")
                                        : page.tr("Lokale Bibliothek · " + ((page.c ? page.c.get("localSubs") : []) || []).length + " Abos", "Local library · " + ((page.c ? page.c.get("localSubs") : []) || []).length + " subscriptions") }
                        }
                    }
                    MouseArea {
                        id: accMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            if (page.c.loggedIn) accMenu.popup()
                            else if (page.c.oauthConfigured) page.openLogin("login")
                            else page.plugin.call("panel.open", { panel: "settings" })
                        }
                    }
                    Menu {
                        id: accMenu
                        MenuItem { text: page.tr("Konto wechseln …", "Switch account …"); onTriggered: page.openLogin("login") }
                        MenuItem { text: page.tr("Verbindung trennen", "Disconnect"); onTriggered: page.openLogin("logout") }
                        MenuSeparator {}
                        MenuItem { text: page.tr("Einstellungen …", "Settings …"); onTriggered: page.plugin.call("panel.open", { panel: "settings" }) }
                    }
                }
            }
            Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: page.cLine }
        }

        // ---- Inhalt --------------------------------------------------------------------------------
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            // Kopfzeile
            Item {
                Layout.fillWidth: true
                implicitHeight: 56
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 14; anchors.rightMargin: 14
                    spacing: 8
                    ToolButton { text: "←"; visible: page.history.length > 0; onClicked: page.goBack(); font.pixelSize: 16
                                 ToolTip.text: page.tr("Zurück", "Back"); ToolTip.visible: hovered }
                    Label {
                        Layout.maximumWidth: Math.max(120, parent.width * 0.32)
                        text: page.viewTitle; color: page.cText; font.pixelSize: 18; font.weight: Font.DemiBold; elide: Text.ElideRight
                    }
                    Button {
                        id: subBtn
                        readonly property bool isChannel: page.view.kind === "browse" && /^UC/.test(page.view.browseId || "")
                        readonly property bool subbed: { var g = page.c ? page.c.libraryGen : 0; return isChannel && page.c.isSubscribed(page.view.browseId) }
                        visible: isChannel
                        text: subbed ? page.tr("✓ Abonniert", "✓ Subscribed") : page.tr("Abonnieren", "Subscribe")
                        highlighted: !subbed
                        onClicked: page.c.toggleSubscribe({ id: page.view.browseId, title: page.viewTitle,
                                                            avatar: page._items.length && page._items[0].avatar ? page._items[0].avatar : "" })
                    }
                    Item { Layout.fillWidth: true }
                    // Suche
                    Rectangle {
                        Layout.preferredWidth: Math.min(360, Math.max(180, parent.width * 0.38))
                        implicitHeight: 36
                        radius: 18
                        color: Qt.rgba(0, 0, 0, 0.25)
                        border.color: searchField.activeFocus ? page.ytRed : page.cLine
                        Behavior on border.color { ColorAnimation { duration: 120 } }
                        RowLayout {
                            anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 4
                            Label { text: "⌕"; color: page.cMuted; font.pixelSize: 17 }
                            TextField {
                                id: searchField
                                Layout.fillWidth: true
                                placeholderText: page.tr("Auf YouTube suchen", "Search YouTube")
                                background: null
                                color: page.cText
                                selectByMouse: true
                                onAccepted: if (text.trim()) page.navigate({ kind: "search", query: text.trim(), filter: "" }, page.view.kind === "search")
                            }
                            ToolButton { visible: searchField.text !== ""; text: "✕"; onClicked: searchField.clear() }
                        }
                    }
                    ToolButton {
                        text: "▶▶"; font.pixelSize: 11
                        visible: tileModel.count > 0 && page.view.kind !== "search" && !(page.view.kind === "tab" && page.view.key === "channels")
                        onClicked: playAllMenu.popup()
                        ToolTip.text: page.tr("Alle abspielen …", "Play all …"); ToolTip.visible: hovered
                        Menu {
                            id: playAllMenu
                            MenuItem { text: page.tr("Alle sofort abspielen (Playlist ersetzen)", "Play all now (replace playlist)"); onTriggered: page.playAll("replace") }
                            MenuItem { text: page.tr("Alle zur Playlist hinzufügen", "Add all to playlist"); onTriggered: page.playAll("queue") }
                        }
                    }
                    ToolButton { text: "⟳"; font.pixelSize: 16; onClicked: page.reload(); ToolTip.text: page.tr("Neu laden", "Reload"); ToolTip.visible: hovered }
                }
            }

            // Suchfilter
            Row {
                Layout.leftMargin: 14
                Layout.bottomMargin: 6
                visible: page.view.kind === "search"
                spacing: 6
                Repeater {
                    model: page.searchFilters
                    delegate: Rectangle {
                        required property var modelData
                        readonly property bool on: (page.view.filter || "") === modelData.params
                        implicitWidth: chipLabel.implicitWidth + 24; implicitHeight: 28; radius: 8
                        color: on ? page.cText : chipMouse.containsMouse ? Qt.rgba(1, 1, 1, 0.12) : Qt.rgba(1, 1, 1, 0.06)
                        Label { id: chipLabel; anchors.centerIn: parent; text: page.tr(modelData.de, modelData.en); color: parent.on ? page.cPanel : page.cText; font.pixelSize: 13 }
                        MouseArea { id: chipMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: page.navigate({ kind: "search", query: page.view.query, filter: modelData.params }, true) }
                    }
                }
            }

            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                ListModel { id: tileModel }

                GridView {
                    id: grid
                    anchors.fill: parent
                    anchors.leftMargin: 10; anchors.rightMargin: 4
                    visible: !page.showLogin
                    clip: true
                    model: tileModel
                    readonly property int gap: 18
                    readonly property int columns: Math.max(1, Math.floor((width - 6) / (page.cfg("tileWidth") + gap)))
                    cellWidth: Math.floor((width - 6) / columns)
                    cellHeight: (cellWidth - gap) * 9 / 16 + 100
                    boundsBehavior: Flickable.StopAtBounds
                    cacheBuffer: 800
                    topMargin: 8
                    bottomMargin: 30
                    ScrollBar.vertical: ScrollBar { }
                    onContentYChanged: if (contentHeight - contentY - height < 900) page.loadMore()
                    delegate: Item {
                        id: cell
                        required property int idx
                        width: grid.cellWidth; height: grid.cellHeight
                        VideoTile {
                            x: grid.gap / 2; y: 6
                            width: cell.width - grid.gap
                            item: page._items[cell.idx] || ({})
                            controller: page.c
                            theme: page.theme
                            hue: page.hue
                            onActivated: page.activate(item, null)
                            onPlayNext: page.c.playVideos([item], "next")
                            onQueue: page.c.playVideos([item], "queue")
                            onLater: page.c.toggleLater(item)
                            onOpenChannel: function (cid, name) { page.navigate({ kind: "browse", browseId: cid, params: "EgZ2aWRlb3PyBgQKAjoA", title: name }, false) }
                            onContextRequested: function (x, y) { ctx.target = item; ctx.popup() }
                        }
                    }
                    footer: Item {
                        width: grid.width; height: page.loadingMore ? 60 : 10
                        BusyIndicator { anchors.centerIn: parent; running: page.loadingMore; visible: running; implicitWidth: 36; implicitHeight: 36 }
                    }
                }

                // Platzhalter beim Laden
                Grid {
                    anchors.fill: grid
                    anchors.margins: 9
                    visible: page.loading && !page.showLogin
                    columns: grid.columns
                    spacing: grid.gap
                    clip: true
                    Repeater {
                        model: grid.columns * 3
                        Column {
                            width: grid.cellWidth - grid.gap
                            spacing: 10
                            Rectangle { width: parent.width; height: width * 9 / 16; radius: page.cfg("tileRadius"); color: Qt.rgba(1, 1, 1, 0.06) }
                            Rectangle { width: parent.width * 0.85; height: 12; radius: 6; color: Qt.rgba(1, 1, 1, 0.06) }
                            Rectangle { width: parent.width * 0.55; height: 10; radius: 5; color: Qt.rgba(1, 1, 1, 0.045) }
                        }
                    }
                    SequentialAnimation on opacity { running: page.loading; loops: Animation.Infinite
                        NumberAnimation { from: 0.5; to: 1; duration: 650; easing.type: Easing.InOutSine }
                        NumberAnimation { from: 1; to: 0.5; duration: 650; easing.type: Easing.InOutSine } }
                }

                // Hinweise: Anmeldung nötig / Fehler / leer / kein WebEngine
                ColumnLayout {
                    anchors.centerIn: parent
                    width: Math.min(parent.width - 40, 440)
                    visible: !page.loading && !page.showLogin && tileModel.count === 0
                    spacing: 14
                    Label {
                        Layout.alignment: Qt.AlignHCenter
                        text: page.error ? (page.view.kind === "tab" && page.view.key !== "home" ? "📭" : "⚠") : "📭"
                        font.pixelSize: 46
                    }
                    Label {
                        Layout.fillWidth: true
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                        color: page.cText; font.pixelSize: 15; font.weight: Font.DemiBold
                        text: !page.sourceAvailable ? "ApiSource.qml"
                            : page.needsLogin ? page.tr("Melde dich mit deinem Google-Konto an, um diesen Bereich zu sehen.", "Sign in with your Google account to see this section.")
                            : page.error ? (page.view.kind === "tab" && ["subs", "history", "later", "liked", "playlists"].indexOf(page.view.key) >= 0 ? page.tr("Hier ist noch nichts.", "Nothing here yet.") : page.tr("YouTube konnte nicht geladen werden.", "Could not load YouTube."))
                            : page.tr("Hier gibt es (noch) nichts zu sehen.", "Nothing to see here (yet).")
                    }
                    Label {
                        Layout.fillWidth: true; visible: page.error !== ""
                        horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
                        color: page.cMuted; font.pixelSize: 12; text: page.error
                    }
                    Button {
                        Layout.alignment: Qt.AlignHCenter
                        visible: page.needsLogin && page.sourceAvailable
                        text: page.tr("  Mit Google anmelden  ", "  Sign in with Google  ")
                        highlighted: true
                        onClicked: page.openLogin("login")
                    }
                    Button {
                        Layout.alignment: Qt.AlignHCenter
                        visible: page.error !== ""
                        text: page.tr("Erneut versuchen", "Try again")
                        onClicked: page.reload()
                    }
                }

                // Anmeldung im Fenster
                Loader {
                    id: loginLoader
                    anchors.fill: parent
                    anchors.margins: 12
                    visible: page.showLogin && status === Loader.Ready
                    Connections {
                        target: loginLoader.item
                        ignoreUnknownSignals: true
                        function onOpenSettings() { page.showLogin = false; page.plugin.call("panel.open", { panel: "settings" }) }
                        function onFinished(loggedIn) {
                            page.showLogin = false
                            // Controller hat Status und Hinweis schon gesetzt
                        }
                        function onCancelled() { page.showLogin = false }
                    }
                }
            }
        }
    }
    function openLogin(mode) {
        if (!c) return
        if (mode === "logout") { c.logoutOAuth(); plugin.osd(tr("YouTube: Google-Konto getrennt", "YouTube: Google account disconnected"), 2000); return }
        loginMode = mode; showLogin = true
        loginLoader.setSource(Qt.resolvedUrl("BrowserLoginView.qml"), { controller: c, theme: theme })
    }
    onShowLoginChanged: if (!showLogin) loginLoader.source = ""

    // Kontextmenü einer Kachel
    Menu {
        id: ctx
        property var target: null
        readonly property bool isVideo: target && target.type === "video"
        MenuItem { text: ctx.isVideo ? page.tr("▶  Jetzt abspielen", "▶  Play now") : page.tr("Öffnen", "Open"); onTriggered: page.activate(ctx.target, ctx.isVideo ? "play" : null) }
        MenuItem { visible: ctx.isVideo; height: visible ? implicitHeight : 0; text: page.tr("⏭  Als Nächstes abspielen", "⏭  Play next"); onTriggered: page.c.playVideos([ctx.target], "next") }
        MenuItem { visible: ctx.isVideo; height: visible ? implicitHeight : 0; text: page.tr("＋  Zur Playlist hinzufügen", "＋  Add to playlist"); onTriggered: page.c.playVideos([ctx.target], "queue") }
        MenuSeparator { visible: ctx.isVideo; height: visible ? implicitHeight : 0 }
        MenuItem {
            visible: ctx.isVideo; height: visible ? implicitHeight : 0
            text: { var g = page.c ? page.c.libraryGen : 0; return ctx.target && page.c.inLater(ctx.target.id) ? page.tr("◷  Aus „Später ansehen“ entfernen", "◷  Remove from “Watch later”") : page.tr("◷  Später ansehen", "◷  Watch later") }
            onTriggered: page.c.toggleLater(ctx.target)
        }
        MenuItem {
            visible: ctx.isVideo; height: visible ? implicitHeight : 0
            text: { var g = page.c ? page.c.libraryGen : 0; return ctx.target && page.c.isFavorite(ctx.target.id) ? page.tr("♥  Aus Favoriten entfernen", "♥  Remove from favourites") : page.tr("♡  Zu Favoriten", "♡  Add to favourites") }
            onTriggered: page.c.toggleFavorite(ctx.target)
        }
        MenuItem {
            readonly property var ch: !ctx.target ? null : ctx.target.type === "channel" ? { id: ctx.target.id, title: ctx.target.title, avatar: ctx.target.avatar }
                                     : ctx.target.channelId ? { id: ctx.target.channelId, title: ctx.target.channel, avatar: ctx.target.avatar || "" } : null
            visible: !!ch; height: visible ? implicitHeight : 0
            text: { var g = page.c ? page.c.libraryGen : 0; return ch && page.c.isSubscribed(ch.id) ? page.tr("✓  Abo beenden: ", "✓  Unsubscribe: ") + ch.title : page.tr("🔔  Abonnieren: ", "🔔  Subscribe: ") + (ch ? ch.title : "") }
            onTriggered: page.c.toggleSubscribe(ch)
        }
        MenuItem {
            visible: !!(ctx.target && ctx.target.channelId) && ctx.target.type !== "channel"; height: visible ? implicitHeight : 0
            text: page.tr("Kanal öffnen: ", "Open channel: ") + (ctx.target ? ctx.target.channel : "")
            onTriggered: page.navigate({ kind: "browse", browseId: ctx.target.channelId, params: "EgZ2aWRlb3PyBgQKAjoA", title: ctx.target.channel }, false)
        }
        MenuSeparator {}
        MenuItem { text: page.tr("Link kopieren", "Copy link"); onTriggered: { clip.text = page.linkOf(ctx.target); clip.selectAll(); clip.copy(); page.plugin.osd(page.tr("Link kopiert", "Link copied"), 1200) } }
        MenuItem { text: page.tr("Im Browser öffnen", "Open in browser"); onTriggered: Qt.openUrlExternally(page.linkOf(ctx.target)) }
        MenuItem {
            visible: !!(ctx.target && ctx.target.channel); height: visible ? implicitHeight : 0
            text: page.tr("Kanal ausblenden", "Hide channel")
            onTriggered: {
                var list = String(page.cfg("blockedChannels") || "")
                page.c.set("blockedChannels", (list ? list + ", " : "") + ctx.target.channel)
                page.reload()
            }
        }
    }
    TextEdit { id: clip; visible: false }
    function linkOf(it) {
        if (!it) return ""
        if (it.type === "video") return "https://www.youtube.com/watch?v=" + it.id
        if (it.type === "playlist") return "https://www.youtube.com/playlist?list=" + it.id
        return "https://www.youtube.com/channel/" + it.id
    }

    Shortcut { sequences: ["Ctrl+F"]; onActivated: searchField.forceActiveFocus() }
    Shortcut { sequences: ["F5"]; onActivated: page.reload() }
    Shortcut { sequences: ["Alt+Left", "Backspace"]; enabled: !searchField.activeFocus; onActivated: page.goBack() }

    // ---- Größe ändern ----------------------------------------------------------------------------
    // Der Player-Dialog hat keine Ziehränder; die Griffe öffnen das Fenster mit neuer Größe erneut.
    // Das Fenster bleibt dabei zentriert, deshalb zählt die Mausbewegung doppelt.
    readonly property bool resizable: c && c.get("modalMode") !== "fill"
    property real _startW: 0
    property real _startH: 0
    property point _startPos
    property real _wantW: 0
    property real _wantH: 0
    Timer { id: resizeTick; interval: 33; onTriggered: page.c.resizeBrowser(page._wantW, page._wantH, false) }
    function _beginResize(m, item) { _startW = width + 2; _startH = height + 38; _startPos = item.mapToGlobal(m.x, m.y) }
    function _doResize(m, item, sx, sy) {
        var p = item.mapToGlobal(m.x, m.y)
        var win = page.Window.window
        var maxW = win ? win.width : 4000, maxH = win ? win.height : 4000
        _wantW = sx ? Math.max(640, Math.min(maxW, _startW + 2 * (p.x - _startPos.x))) : _startW
        _wantH = sy ? Math.max(420, Math.min(maxH, _startH + 2 * (p.y - _startPos.y))) : _startH
        if (!resizeTick.running) resizeTick.start()
    }
    function _endResize() { resizeTick.stop(); c.resizeBrowser(_wantW || _startW, _wantH || _startH, true) }

    Repeater {
        model: page.resizable ? [
            { sx: true, sy: false, cursor: Qt.SizeHorCursor },
            { sx: false, sy: true, cursor: Qt.SizeVerCursor },
            { sx: true, sy: true, cursor: Qt.SizeFDiagCursor }
        ] : []
        delegate: MouseArea {
            id: grip
            required property var modelData
            z: 100
            x: modelData.sx ? page.width - (modelData.sy ? 18 : 6) : 0
            y: modelData.sy ? page.height - (modelData.sx ? 18 : 6) : 0
            width: modelData.sx ? (modelData.sy ? 18 : 6) : page.width - 18
            height: modelData.sy ? (modelData.sx ? 18 : 6) : page.height - 18
            hoverEnabled: true
            preventStealing: true
            cursorShape: modelData.cursor
            onPressed: function (m) { page._wantW = 0; page._wantH = 0; page._beginResize(m, grip) }
            onPositionChanged: function (m) { if (pressed) page._doResize(m, grip, grip.modelData.sx, grip.modelData.sy) }
            onReleased: page._endResize()
            onDoubleClicked: page.c.resizeBrowser(1120, 720, true)
            // sichtbarer Griff in der Ecke
            Canvas {
                visible: modelData.sx && modelData.sy
                anchors.fill: parent
                opacity: parent.containsMouse || parent.pressed ? 0.9 : 0.4
                onPaint: {
                    var g = getContext("2d"); g.clearRect(0, 0, width, height)
                    g.strokeStyle = String(page.cMuted); g.lineWidth = 1.5
                    for (var i = 0; i < 3; i++) { g.beginPath(); g.moveTo(width - 3, 5 + i * 4); g.lineTo(5 + i * 4, height - 3); g.stroke() }
                }
            }
        }
    }
}
