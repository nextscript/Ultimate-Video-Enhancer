import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Google-Konto verbinden: Der Standardbrowser öffnet Google (OAuth 2.0 für Desktop-Apps, Authorization Code Flow mit PKCE).
// Nach „Zulassen“ leitet Google auf http://127.0.0.1:<Port> zurück; das Plugin tauscht den Code gegen Tokens.
Rectangle {
    id: root
    property var controller
    property var theme
    signal finished(bool loggedIn)
    signal cancelled()
    signal openSettings()

    readonly property var c: controller
    function tr(de, en) { return c ? c.t(de, en) : de }
    readonly property color cText: theme ? theme.text : "#e6e8eb"
    readonly property color cMuted: theme ? theme.muted : "#8b93a1"
    readonly property string st: c ? c.deviceState : "idle"

    implicitHeight: col.implicitHeight + 48
    radius: 14
    color: theme ? theme.panel2 : "#1b1f26"
    border.color: theme ? theme.line : "#262b34"

    Component.onCompleted: if (c && c.oauthConfigured && st !== "waiting" && st !== "exchanging") c.startLogin()
    Connections {
        target: root.c
        ignoreUnknownSignals: true
        function onDeviceStateChanged() { if (root.c.deviceState === "done") root.finished(true) }
    }

    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 24 }
        spacing: 16

        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            spacing: 12
            Rectangle {
                implicitWidth: 44; implicitHeight: 44; radius: 22; color: "white"
                Label { anchors.centerIn: parent; text: "G"; font.pixelSize: 24; font.bold: true; color: "#4285f4" }
            }
            Label {
                text: "⟷"; color: root.st === "waiting" ? "#ff0033" : root.cMuted; font.pixelSize: 22
                SequentialAnimation on opacity { running: root.st === "waiting" || root.st === "exchanging"; loops: Animation.Infinite
                    NumberAnimation { from: 1; to: 0.25; duration: 700 } NumberAnimation { from: 0.25; to: 1; duration: 700 } }
            }
            Rectangle {
                implicitWidth: 52; implicitHeight: 36; radius: 9; color: "#ff0033"
                Label { anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; text: "▶"; color: "white"; font.pixelSize: 16 }
            }
        }
        Label {
            Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
            color: root.cText; font.pixelSize: 18; font.weight: Font.DemiBold
            text: root.st === "waiting" ? root.tr("Im Browser anmelden", "Sign in in your browser")
                : root.st === "exchanging" ? root.tr("Verbinde …", "Connecting …")
                : root.st === "error" ? root.tr("Das hat nicht geklappt", "That did not work")
                : !(root.c && root.c.oauthConfigured) ? root.tr("Einmalige Einrichtung nötig", "One-time setup needed")
                : root.tr("Öffne Google …", "Opening Google …")
        }
        Label {
            visible: root.st === "waiting"
            Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap; color: root.cMuted
            text: root.tr("Dein Standardbrowser hat sich geöffnet. Wähle dort dein Google-Konto und klicke auf „Zulassen“ – danach geht es hier automatisch weiter.",
                          "Your default browser has opened. Choose your Google account there and click “Allow” – this continues automatically afterwards.")
        }
        RowLayout {
            visible: root.st === "waiting" || root.st === "exchanging"
            Layout.alignment: Qt.AlignHCenter
            BusyIndicator { implicitWidth: 26; implicitHeight: 26; running: parent.visible }
            Label { text: root.st === "exchanging" ? root.tr("Hole Zugangsdaten …", "Getting tokens …") : root.tr("Warte auf Google …", "Waiting for Google …"); color: root.cMuted }
        }
        Button {
            visible: root.st === "waiting"
            Layout.alignment: Qt.AlignHCenter
            text: root.tr("Browser erneut öffnen", "Open browser again")
            onClicked: root.c.openVerification()
        }
        Label {
            visible: root.st === "error"
            Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
            color: root.theme ? root.theme.error : "#ff6b6b"
            text: root.c ? root.c.deviceError : ""
        }
        Label {
            visible: !(root.c && root.c.oauthConfigured)
            Layout.fillWidth: true; wrapMode: Text.Wrap; color: root.cMuted; textFormat: Text.StyledText
            onLinkActivated: function (l) { Qt.openUrlExternally(l) }
            text: root.tr("Dafür braucht Google eine OAuth-Client-ID vom Typ <b>„Desktop-App“</b> "
                        + "(<a href=\"https://console.cloud.google.com/apis/credentials\">Google Cloud Console → Anmeldedaten</a>). "
                        + "Client-ID und Client-Secret unter <b>Einstellungen → YouTube → Google-Konto verbinden</b> eintragen.",
                          "Google needs an OAuth client ID of type <b>“Desktop app”</b> for this "
                        + "(<a href=\"https://console.cloud.google.com/apis/credentials\">Google Cloud Console → Credentials</a>). "
                        + "Enter the client ID and secret under <b>Settings → YouTube → Connect a Google account</b>.")
        }
        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            spacing: 8
            Button {
                visible: root.st === "error" && root.c && root.c.oauthConfigured
                text: root.tr("Erneut versuchen", "Try again"); highlighted: true
                onClicked: root.c.startLogin()
            }
            Button {
                visible: !(root.c && root.c.oauthConfigured)
                text: root.tr("Zu den Einstellungen", "Open settings"); highlighted: true
                onClicked: root.openSettings()
            }
            Button { text: root.tr("Abbrechen", "Cancel"); onClicked: { root.c.cancelDeviceLogin(); root.cancelled() } }
        }
    }
}
