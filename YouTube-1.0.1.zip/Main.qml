import QtQml

// Logik des YouTube-Plugins (nicht sichtbar). Seiten erhalten dieses Objekt als "controller".
// Daten kommen über die offizielle YouTube Data API (API-Key, ohne Anmeldung). Abos, Verlauf, Später ansehen und
// Favoriten verwaltet das Plugin lokal. Optional: Google-Konto über den Standardbrowser verbinden (eigene OAuth-Client-ID).
QtObject {
    id: root
    property var plugin

    // ---- Zustand -----------------------------------------------------------------------------
    property var cfg: ({})
    property bool loggedIn: false           // Google-Konto verbunden (OAuth)
    property var account: null              // { name, handle, photo }
    property int sessionGen: 0              // erhöht sich nach Verbinden/Trennen -> Seiten laden neu
    property int libraryGen: 0              // erhöht sich bei Änderungen an Abos/Verlauf/Später/Favoriten
    readonly property string lang: plugin ? String(plugin.language || "de").substring(0, 2) : "de"
    property bool _ready: false

    // fest eingebauter API-Key (verschlüsselt abgelegt, nicht änderbar)
    readonly property string apiKey: _k(["a70291b4bf12387f8799e06b23", "6967f6e2701869493865f4534c", "e51b23ac360b883aef4e3f8e18"], 401008035)
    // OAuth-Client (Desktop-App), ebenfalls verschlüsselt abgelegt
    readonly property string clientId: _k(["c3c67c9b047f053042245fe47806bc74d24863935e571d9e", "99cd230b2e082829b945ded53bc65efa81c515a4e5c580be", "dba1e29eb9adf3007dff64a66bbdf736839b17a6c3135c9f"], 316316055)
    readonly property string clientSecret: _k(["5e8a0401214cdbbf59050bc", "c6d94b3c389a431fbdeab6a", "473f5da6a758225b7dbdf3ac"], 1551381043)
    function _k(p, s) {
        var h = p.join(""), b = []
        for (var i = 0; i < h.length; i += 2) b.push(parseInt(h.substr(i, 2), 16))
        b.reverse()
        var out = ""
        for (var j = 0; j < b.length; j++) {
            s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff
            out += String.fromCharCode(b[j] ^ ((s >> 16) & 255) ^ ((j * 29) & 255))
        }
        return out
    }

    readonly property var defaults: ({
        channelHandle: "",         // eigener Kanal (@name) für den Import öffentlicher Abos und Playlists
        myChannelId: "",
        localSubs: [],             // [{id, title, avatar}]
        history: [],               // zuletzt abgespielte Videos (neueste zuerst)
        watchLater: [],
        favorites: [],
        historyEnabled: true,
        subsFeedChannels: 40,      // so viele Abos fließen in den Abos-Feed ein
        startTab: "home",          // home | subs | channels | history | later | liked | playlists
        clickAction: "play",       // play | next | queue
        closeOnPlay: true,
        hideShorts: true,
        hideLive: false,
        hideWatched: false,
        showProgress: true,
        showAvatars: true,
        tileWidth: 260,
        thumbQuality: "hq",        // mq | hq | max
        hoverColor: "#ff0033",
        hoverStyle: "solid",       // solid | rainbow | gradient
        hoverWidth: 3,
        tileRadius: 12,
        hoverGlow: true,
        hoverZoom: true,
        hoverLift: true,
        compactSidebar: false,
        modalScope: "player",
        modalMode: "movable",
        modalWidth: 1120,
        modalHeight: 720,
        hl: "",                    // leer = Sprache des Players
        gl: "",                    // leer = automatisch
        blockedChannels: ""
    })

    signal sessionChanged()

    // ---- Google-Konto verbinden: OAuth 2.0 für Desktop-Apps, Authorization Code Flow mit PKCE ----------
    // Standardbrowser öffnet Google; Google leitet auf http://127.0.0.1:<Port> zurück, wo oauth/uve_oauth.dll lauscht.
    property var api: null                 // ApiSource
    readonly property bool oauthMode: loggedIn      // Konto verbunden -> persönliche Daten über OAuth
    readonly property bool oauthConfigured: !!clientId && !!clientSecret
    property string deviceState: "idle"    // idle | starting | waiting | exchanging | done | error
    property string deviceError: ""
    property string authUrl: ""
    property var _oauth: null              // OAuthLoopback (native Erweiterung)
    property string oauthUnavailable: ""
    property string _verifier: ""
    property string _state: ""
    property string _redirectUri: ""
    readonly property string scope: "https://www.googleapis.com/auth/youtube.readonly"

    function _post(url, params, cb) {
        var x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            var j = null
            try { j = JSON.parse(x.responseText) } catch (e) { j = null }
            cb(x.status, j || {})
        }
        x.open("POST", url)
        x.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
        var a = []
        for (var k in params) a.push(encodeURIComponent(k) + "=" + encodeURIComponent(params[k]))
        x.send(a.join("&"))
    }

    function _page(title, text, ok) {
        return "<!doctype html><html><head><meta charset='utf-8'><title>UVE Player – YouTube</title><style>"
             + "body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#0b0d10;color:#e6e8eb;font-family:Segoe UI,system-ui,sans-serif}"
             + ".c{text-align:center;padding:40px 48px;border-radius:18px;background:#14171c;border:1px solid #262b34;max-width:440px}"
             + ".i{width:64px;height:64px;border-radius:32px;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;background:"
             + (ok ? "#1db954" : "#ff0033") + "}h1{font-size:22px;margin:0 0 10px}p{color:#8b93a1;margin:0;line-height:1.5}</style></head><body><div class='c'><div class='i'>"
             + (ok ? "✓" : "!") + "</div><h1>" + title + "</h1><p>" + text + "</p></div></body></html>"
    }

    function oauthHelper() {
        if (_oauth) return _oauth
        try {
            _oauth = Qt.createQmlObject("import \"" + plugin.resolve("oauth") + "\"\nOAuthLoopback {}", root, "OAuthLoopback")
            _oauth.redirected.connect(_onRedirect)
            oauthUnavailable = ""
        } catch (e) {
            _oauth = null
            oauthUnavailable = t("Die OAuth-Erweiterung (oauth/uve_oauth.dll) konnte nicht geladen werden: ", "The OAuth extension (oauth/uve_oauth.dll) could not be loaded: ") + e
            plugin.log("YouTube: " + oauthUnavailable, "error")
        }
        return _oauth
    }

    function startLogin() {
        if (!oauthConfigured) {
            deviceState = "error"
            deviceError = t("Bitte zuerst Client-ID und Client-Secret eintragen (Einstellungen → YouTube → Google-Konto verbinden).",
                            "Please enter the client ID and client secret first (Settings → YouTube → Connect a Google account).")
            return
        }
        var h = oauthHelper()
        if (!h) { deviceState = "error"; deviceError = oauthUnavailable; return }
        var port = h.listen()
        if (!port) { deviceState = "error"; deviceError = t("Konnte keinen lokalen Port öffnen.", "Could not open a local port."); return }
        _verifier = h.randomVerifier(64)
        _state = h.randomState()
        _redirectUri = "http://127.0.0.1:" + port
        h.successHtml = _page(t("Verbunden!", "Connected!"), t("Du kannst dieses Fenster schließen und zum UVE Player zurückkehren.", "You can close this window and return to UVE Player."), true)
        h.errorHtml = _page(t("Nicht verbunden", "Not connected"), t("Der Zugriff wurde nicht erteilt. Du kannst es im UVE Player erneut versuchen.", "Access was not granted. You can try again in UVE Player."), false)
        var q = {
            client_id: clientId, redirect_uri: _redirectUri, response_type: "code", scope: scope,
            code_challenge: h.challenge(_verifier), code_challenge_method: "S256", state: _state,
            access_type: "offline", prompt: "consent", include_granted_scopes: "true"
        }
        var parts = []
        for (var k in q) parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(q[k]))
        authUrl = "https://accounts.google.com/o/oauth2/v2/auth?" + parts.join("&")
        deviceError = ""
        deviceState = "waiting"
        loginTimeout.restart()
        openVerification()
    }
    function openVerification() { if (authUrl) Qt.openUrlExternally(authUrl) }
    function cancelDeviceLogin() { loginTimeout.stop(); if (_oauth) _oauth.close(); deviceState = "idle"; authUrl = "" }
    function startDeviceLogin() { startLogin() }   // alter Name

    property Timer loginTimeout: Timer {
        interval: 5 * 60 * 1000
        onTriggered: {
            if (root.deviceState !== "waiting") return
            if (root._oauth) root._oauth.close()
            root.deviceState = "error"
            root.deviceError = root.t("Zeit abgelaufen – bitte erneut verbinden.", "Timed out – please connect again.")
        }
    }

    function _onRedirect(p) {
        if (deviceState !== "waiting") return
        loginTimeout.stop()
        if (p.state !== _state) { deviceState = "error"; deviceError = t("Ungültige Antwort (state stimmt nicht).", "Invalid response (state mismatch)."); return }
        if (p.error || !p.code) {
            deviceState = "error"
            deviceError = p.error === "access_denied" ? t("Der Zugriff wurde im Browser abgelehnt.", "Access was denied in the browser.")
                                                      : t("Google meldet: ", "Google reports: ") + (p.error_description || p.error || "?")
            return
        }
        deviceState = "exchanging"
        _post("https://oauth2.googleapis.com/token", {
            code: p.code, client_id: clientId, client_secret: clientSecret,
            code_verifier: _verifier, grant_type: "authorization_code", redirect_uri: _redirectUri
        }, function (st, j) {
            _verifier = ""
            if (st !== 200 || !j.access_token) {
                deviceState = "error"
                deviceError = t("Token-Austausch fehlgeschlagen: ", "Token exchange failed: ") + (j.error_description || j.error || ("HTTP " + st))
                return
            }
            set("oauth", { access: j.access_token, refresh: j.refresh_token || "", expiresAt: Date.now() + (j.expires_in || 3600) * 1000 })
            loggedIn = true
            if (api) { api._subs = null; api._feed = null }
            deviceState = "done"
            api.request("status", {}, function (ok, d) {
                setStatus(true, ok && d ? d.account : null)
                loginFinished()
                plugin.osd(t("YouTube: Google-Konto verbunden ✓", "YouTube: Google account connected ✓"), 2000)
            })
        })
    }

    property var _refreshWaiters: []
    function refreshToken(cb) {
        var o = get("oauth") || {}
        if (!o.refresh) { cb(false, t("Sitzung abgelaufen – bitte erneut anmelden.", "Session expired – please sign in again.")); return }
        _refreshWaiters.push(cb)
        if (_refreshWaiters.length > 1) return
        _post("https://oauth2.googleapis.com/token", { client_id: clientId, client_secret: clientSecret,
                                                       refresh_token: o.refresh, grant_type: "refresh_token" }, function (st, j) {
            var waiters = _refreshWaiters
            _refreshWaiters = []
            if (st === 200 && j.access_token) {
                var n = Object.assign({}, get("oauth"))
                n.access = j.access_token
                n.expiresAt = Date.now() + (j.expires_in || 3600) * 1000
                set("oauth", n)
                waiters.forEach(function (w) { w(true, j.access_token) })
            } else {
                if (j.error === "invalid_grant") { set("oauth", {}); setStatus(false, null) }
                var err = t("Anmeldung abgelaufen – bitte erneut anmelden.", "Sign-in expired – please sign in again.")
                waiters.forEach(function (w) { w(false, err) })
            }
        })
    }
    function logoutOAuth() {
        var o = get("oauth") || {}
        var tok = o.refresh || o.access
        if (tok) _post("https://oauth2.googleapis.com/revoke", { token: tok }, function () {})
        set("oauth", {})
        if (api) { api._subs = null; api._feed = null }
        setStatus(false, null)
        loginFinished()
    }

    function t(de, en) { return lang === "de" ? de : en }
    function get(key) { return cfg[key] !== undefined ? cfg[key] : defaults[key] }
    function set(key, value) {
        var c = Object.assign({}, cfg); c[key] = value; cfg = c
        if (plugin) plugin.saveSettings(cfg)
        if (key === "hl" || key === "gl") { sessionGen++ }
    }
    function resetSettings() {
        var keep = {}
        ;["oauth", "channelHandle", "myChannelId", "localSubs", "history",
          "watchLater", "favorites", "lastAccount"].forEach(function (k) { if (cfg[k] !== undefined) keep[k] = cfg[k] })
        cfg = keep
        if (plugin) plugin.saveSettings(cfg)
        sessionGen++
    }
    function hl() { return get("hl") || lang }
    function gl() { return get("gl") || "" }

    // ---- Lebenszyklus -------------------------------------------------------------------------
    onPluginChanged: init()
    function activate() { init() }
    function suspend() {}
    function deactivate() {}

    function init() {
        if (_ready || !plugin) return
        _ready = true
        cfg = plugin.settings() || {}
        var apiComp = Qt.createComponent(plugin.resolve("ApiSource.qml"))
        if (apiComp.status === Component.Ready) api = apiComp.createObject(root, { controller: root })
        else plugin.log("YouTube: ApiSource: " + apiComp.errorString(), "error")
        loggedIn = !!(get("oauth") || {}).refresh
        if (loggedIn && cfg.lastAccount) account = cfg.lastAccount
    }

    function setStatus(isLoggedIn, acc) {
        var changed = loggedIn !== isLoggedIn
        loggedIn = isLoggedIn
        if (acc) account = acc
        if (!isLoggedIn) account = null
        var c = Object.assign({}, cfg); c.lastAccount = account; cfg = c
        plugin.saveSettings(cfg)
        if (changed) sessionChanged()
    }
    function loginFinished() { sessionGen++; sessionChanged() }

    // ---- Lokale Bibliothek --------------------------------------------------------------------
    function _slim(v) {
        return { type: "video", id: v.id, title: v.title || "", channel: v.channel || "", channelId: v.channelId || "",
                 duration: v.duration || "", avatar: v.avatar || "", views: "", age: "", live: !!v.live, short: !!v.short, progress: 0 }
    }
    function _listHas(key, id) { return (get(key) || []).some(function (x) { return x.id === id }) }
    function _listToggle(key, item, max) {
        var l = (get(key) || []).slice()
        var i = l.findIndex(function (x) { return x.id === item.id })
        if (i >= 0) l.splice(i, 1); else l.unshift(item)
        if (max && l.length > max) l = l.slice(0, max)
        set(key, l); libraryGen++
        return i < 0
    }
    function isSubscribed(channelId) { return !!channelId && _listHas("localSubs", channelId) }
    function toggleSubscribe(ch) {
        if (!ch || !ch.id) return
        var on = _listToggle("localSubs", { id: ch.id, title: ch.title || "", avatar: ch.avatar || "" })
        if (api) { api._feed = null }
        plugin.osd((on ? t("Abonniert: ", "Subscribed: ") : t("Abo beendet: ", "Unsubscribed: ")) + (ch.title || ""), 1800)
    }
    function inLater(id) { return _listHas("watchLater", id) }
    function toggleLater(v) {
        var on = _listToggle("watchLater", _slim(v), 500)
        plugin.osd(on ? t("Zu „Später ansehen“ hinzugefügt", "Added to “Watch later”") : t("Aus „Später ansehen“ entfernt", "Removed from “Watch later”"), 1500)
    }
    function isFavorite(id) { return _listHas("favorites", id) }
    function toggleFavorite(v) {
        var on = _listToggle("favorites", _slim(v), 1000)
        plugin.osd(on ? t("♥ Zu Favoriten hinzugefügt", "♥ Added to favourites") : t("Aus Favoriten entfernt", "Removed from favourites"), 1500)
    }
    function addHistory(vids) {
        if (!get("historyEnabled")) return
        var l = (get("history") || []).filter(function (x) { return !vids.some(function (v) { return v.id === x.id }) })
        set("history", vids.map(_slim).concat(l).slice(0, 300)); libraryGen++
    }
    function clearHistory() { set("history", []); libraryGen++ }

    // Öffentliche Abos eines Kanals (@name) übernehmen; die Abos müssen auf YouTube öffentlich sein
    function importSubscriptions(handle, cb) {
        if (!api) { cb(false, "api"); return }
        api.resolveHandle(handle, function (ok, ch) {
            if (!ok) { cb(false, ch); return }
            set("channelHandle", handle); set("myChannelId", ch.id)
            api.publicSubscriptions(ch.id, function (ok2, list) {
                if (!ok2) { cb(false, list); return }
                var l = (get("localSubs") || []).slice(), added = 0
                list.forEach(function (s) { if (!l.some(function (x) { return x.id === s.id })) { l.push(s); added++ } })
                set("localSubs", l); libraryGen++
                if (api) api._feed = null
                cb(true, { channel: ch, added: added, total: list.length })
            })
        })
    }

    // ---- Wiedergabe ---------------------------------------------------------------------------
    function videoUrl(id) { return "https://www.youtube.com/watch?v=" + id }
    function durationSeconds(s) {
        if (!s || !/\d:\d/.test(s)) return 0
        return s.split(":").reduce(function (acc, p) { return acc * 60 + (parseInt(p, 10) || 0) }, 0)
    }
    function playVideos(items, action) {
        var vids = items.filter(function (i) { return i && i.type === "video" })
        if (!vids.length) return
        var args = { urls: vids.map(function (v) { return videoUrl(v.id) }),
                     titles: vids.map(function (v) { return v.title || "" }),
                     durations: vids.map(function (v) { return durationSeconds(v.duration) }) }
        action = action || get("clickAction")
        if (action === "play") args.play = true
        else if (action === "next") args.next = true
        else if (action === "replace") { args.replace = true; args.play = true }
        plugin.call("playlist.add", args)
        if (action === "play" || action === "replace") addHistory(vids.slice(0, 50))
        var n = vids.length
        var msg = action === "play" || action === "replace" ? t("▶ YouTube: ", "▶ YouTube: ") + (n === 1 ? vids[0].title : n + t(" Videos", " videos"))
                : action === "next" ? t("Als Nächstes: ", "Up next: ") + (n === 1 ? vids[0].title : n + t(" Videos", " videos"))
                : t("Zur Playlist hinzugefügt: ", "Added to playlist: ") + (n === 1 ? vids[0].title : n + t(" Videos", " videos"))
        plugin.osd(msg, 2200)
        if ((action === "play" || action === "replace") && get("closeOnPlay")) plugin.call("modal.close", { panel: "browser" })
    }

    // ---- Fenster ------------------------------------------------------------------------------
    function openBrowser(tab, extra) {
        var args = { panel: "browser", scope: get("modalScope"), mode: get("modalMode"),
                     width: get("modalWidth"), height: get("modalHeight"),
                     data: Object.assign({ tab: tab || "", nonce: Date.now() }, extra || {}) }
        plugin.call("modal.open", args)
    }
    // Größenänderung aus der Seite heraus (der Player selbst hat keine Ränder zum Ziehen)
    function resizeBrowser(w, h, save) {
        plugin.call("modal.open", { panel: "browser", scope: get("modalScope"), mode: get("modalMode"),
                                    width: Math.round(w), height: Math.round(h), data: { resize: true } })
        if (save) {
            var c = Object.assign({}, cfg); c.modalWidth = Math.round(w); c.modalHeight = Math.round(h); cfg = c
            plugin.saveSettings(cfg)
        }
    }

    property Connections events: Connections {
        target: root.plugin
        function onEvent(name, data) {
            if (name !== "action.triggered") return
            if (data.id === "open") root.openBrowser(root.get("startTab"))
            else if (data.id === "open-subs") root.openBrowser("subs")
            else if (data.id === "open-search") root.openBrowser("", { focusSearch: true })
            else if (data.id === "open-settings") root.plugin.call("panel.open", { panel: "settings" })
        }
    }
}
