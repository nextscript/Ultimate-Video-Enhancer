# YouTube-Plugin für UVE Player

YouTube direkt im Player – **ohne Anmeldung, ohne Einrichtung**. Ein Klick spielt das Video im UVE Player ab (über yt-dlp).

## Installation

*Einstellungen → Plugins → Plugin installieren …* → `YouTube-1.0.1.zip` wählen → Player neu starten.
Voraussetzung: UVE Player ≥ 1.3.0.

## Öffnen

- Menü **Plugins → YouTube öffnen …** (oder *YouTube: Abos*, *YouTube: Suchen …*)
- Tastenkürzel **Strg+Alt+Y**
- **Einstellungen → YouTube** – eigene Seite mit allen Optionen

## Bereiche

| Bereich | Quelle |
|---|---|
| Trends | YouTube-Trends deines Landes |
| Abos | Kanäle, die du im Plugin abonnierst (Kanal öffnen → *Abonnieren*, oder Rechtsklick auf ein Video) – neueste Videos aller Abos zusammengeführt |
| Kanäle | deine Abos als Liste |
| Verlauf | Videos, die du über das Plugin abspielst |
| Später ansehen | ◷ auf der Kachel oder Rechtsklick |
| Favoriten | Rechtsklick → *Zu Favoriten* |
| Playlists | öffentliche Playlists deines Kanals (nach dem Import) |
| Suche | Videos, Live, Kanäle, Playlists |

**YouTube-Abos übernehmen:** *Einstellungen → YouTube → Abos* → deinen Kanal als `@name` eintragen → *Importieren*.
Dafür müssen deine Abos auf YouTube öffentlich sein (YouTube → Einstellungen → Datenschutz → „Alle meine Abos privat halten“ aus).

**Google-Konto verbinden (optional):** *Mit Google verbinden* öffnet deinen Standardbrowser (OAuth 2.0 für Desktop-Apps,
Authorization Code Flow mit PKCE, Rückleitung auf `http://127.0.0.1`). Danach kommen Abos, „Mag ich“ und deine Playlists
direkt vom Konto (nur Lesezugriff). Die Rückleitung empfängt `oauth/uve_oauth.dll` (Windows x64).

## Kacheln & Hover

Beim Überfahren mit der Maus bekommt jedes Vorschaubild einen Rahmen. Einstellbar: Farbe (8 Vorgaben, eigener Hex-Wert,
**Regenbogen** animiert, **zweifarbig** wandernd), Stärke, Ecken-Rundung, Leuchten, Zoom, Anheben, Kachelgröße – mit
Live-Vorschau. Auf jeder Kachel: ◷ *Später ansehen*, ⏭ *Als Nächstes*, + *Zur Playlist*; Rechtsklick für mehr.

## Fenster

Am **rechten bzw. unteren Rand und an der Ecke unten rechts** ziehen, um die Größe zu ändern; die Größe wird gespeichert,
ein Doppelklick auf den Rand setzt sie zurück. Bereich und Modus unter *Einstellungen → YouTube → Fenster*.
